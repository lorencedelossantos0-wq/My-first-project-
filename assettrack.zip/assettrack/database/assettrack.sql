-- AssetTrack: Equipment & Asset Management System (CC 106 Final Project)
-- Import via phpMyAdmin / HeidiSQL, or: mysql -u root < assettrack.sql

DROP DATABASE IF EXISTS assettrack;
CREATE DATABASE assettrack CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE assettrack;

-- ---------- Lookup tables ----------
CREATE TABLE categories (
  category_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE locations (
  location_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE suppliers (
  supplier_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL UNIQUE,
  contact_email VARCHAR(120) NULL,
  phone         VARCHAR(30)  NULL
) ENGINE=InnoDB;

CREATE TABLE departments (
  department_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ---------- Core tables ----------
CREATE TABLE employees (
  employee_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  department_id INT UNSIGNED NOT NULL,
  CONSTRAINT fk_emp_dept FOREIGN KEY (department_id) REFERENCES departments(department_id)
) ENGINE=InnoDB;

CREATE TABLE users (
  user_id       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  username      VARCHAR(40)  NOT NULL UNIQUE,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','user') NOT NULL DEFAULT 'user',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE assets (
  asset_id       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  asset_tag      VARCHAR(30)  NOT NULL UNIQUE,
  name           VARCHAR(120) NOT NULL,
  serial_no      VARCHAR(60)  NULL,
  category_id    INT UNSIGNED NOT NULL,
  supplier_id    INT UNSIGNED NULL,
  location_id    INT UNSIGNED NOT NULL,
  custodian_id   INT UNSIGNED NULL,
  purchase_date  DATE NOT NULL,
  purchase_cost  DECIMAL(12,2) NOT NULL,
  status         ENUM('Available','In Use','Under Repair','Retired') NOT NULL DEFAULT 'Available',
  created_by     INT UNSIGNED NOT NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_asset_cat  FOREIGN KEY (category_id)  REFERENCES categories(category_id),
  CONSTRAINT fk_asset_sup  FOREIGN KEY (supplier_id)  REFERENCES suppliers(supplier_id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_loc  FOREIGN KEY (location_id)  REFERENCES locations(location_id),
  CONSTRAINT fk_asset_emp  FOREIGN KEY (custodian_id) REFERENCES employees(employee_id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_user FOREIGN KEY (created_by)   REFERENCES users(user_id),
  INDEX idx_asset_status (status)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
  log_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  asset_id   INT UNSIGNED NULL,
  action     ENUM('CREATE','UPDATE','DELETE','EXPORT','LOGIN') NOT NULL,
  details    VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_log_user  FOREIGN KEY (user_id)  REFERENCES users(user_id),
  CONSTRAINT fk_log_asset FOREIGN KEY (asset_id) REFERENCES assets(asset_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- Sample data ----------
-- Demo logins:  admin / Admin@123   and   staff / User@123
INSERT INTO users (full_name, username, email, password_hash, role) VALUES
('System Administrator', 'admin', 'admin@assettrack.test', '$2b$12$ASqYIoko0sxLQFGynC6Lp.0GvTxUQ4BZsDLRJrr46x4t45NouyDJu', 'admin'),
('Regular Staff',        'staff', 'staff@assettrack.test', '$2b$12$aPAZrZUHFtOfKpkwIvili.bx.JgvWR1M5iAgKTiE635U7scbazBlG', 'user');

INSERT INTO categories (name) VALUES ('Laptop'),('Desktop'),('Printer'),('Networking'),('Furniture'),('Projector');
INSERT INTO locations (name) VALUES ('IT Office'),('Computer Lab 1'),('Computer Lab 2'),('Faculty Room'),('Storage Room');
INSERT INTO suppliers (name, contact_email, phone) VALUES
('TechSource Inc.', 'sales@techsource.test', '0917-000-1111'),
('OfficeWorld Trading', 'orders@officeworld.test', '0918-000-2222'),
('NetGear Solutions', 'support@netgear-sol.test', '0919-000-3333');
INSERT INTO departments (name) VALUES ('IT Department'),('Accounting'),('Faculty'),('Registrar');
INSERT INTO employees (full_name, email, department_id) VALUES
('Maria Santos',   'maria.santos@school.test',  1),
('Jose Reyes',     'jose.reyes@school.test',    3),
('Ana Dela Cruz',  'ana.delacruz@school.test',  2),
('Carlo Mendoza',  'carlo.mendoza@school.test', 4);

INSERT INTO assets (asset_tag, name, serial_no, category_id, supplier_id, location_id, custodian_id, purchase_date, purchase_cost, status, created_by) VALUES
('AST-0001', 'Dell Latitude 5440',      'DL5440-A1',  1, 1, 1, 1,    '2024-03-12', 48500.00, 'In Use',       1),
('AST-0002', 'HP ProDesk 400 G9',       'HP400-B7',   2, 1, 2, NULL, '2023-08-01', 32000.00, 'Available',    1),
('AST-0003', 'Epson EcoTank L3250',     'EP3250-C3',  3, 2, 4, 2,    '2024-01-20', 11500.00, 'In Use',       1),
('AST-0004', 'Cisco Catalyst 2960',     'CS2960-D9',  4, 3, 1, 1,    '2022-11-05', 27800.00, 'In Use',       1),
('AST-0005', 'Lenovo ThinkPad E14',     'LT-E14-F2',  1, 1, 5, NULL, '2023-05-16', 41200.00, 'Under Repair', 2),
('AST-0006', 'Epson EB-X49 Projector',  'EB-X49-G5',  6, 2, 3, 3,    '2021-09-09', 24900.00, 'In Use',       1),
('AST-0007', 'Executive Office Chair',  NULL,         5, 2, 4, 2,    '2020-02-14',  6800.00, 'Retired',      1),
('AST-0008', 'TP-Link Wi-Fi 6 Router',  'TPL-AX-H8',  4, 3, 2, NULL, '2024-06-30',  5400.00, 'Available',    2),
('AST-0009', 'Acer Aspire Desktop',     'ACR-ASP-J4', 2, 1, 3, 4,    '2022-04-04', 29900.00, 'In Use',       1),
('AST-0010', 'Brother HL-L2375DW',      'BR-2375-K6', 3, 2, 1, 3,    '2023-10-10', 13200.00, 'Available',    2);

INSERT INTO audit_logs (user_id, asset_id, action, details) VALUES
(1, 1, 'CREATE', 'Added asset AST-0001'),
(1, 2, 'CREATE', 'Added asset AST-0002'),
(2, 5, 'UPDATE', 'Changed status of AST-0005 to Under Repair');
