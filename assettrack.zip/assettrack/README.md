# AssetTrack - Equipment & Asset Management (CC 106 Final Project)

PHP + MySQL (PDO) web app for tracking school/office equipment, with an audit log.

## Setup on Laragon
1. Copy this folder to `C:\laragon\www\assettrack`.
2. Start Laragon (Apache + MySQL).
3. Open HeidiSQL or phpMyAdmin and run `database/assettrack.sql` (it creates the `assettrack` database).
4. Visit `http://localhost/assettrack/` (or `http://assettrack.test` after Laragon's auto virtual host reloads).
5. Check `config/db.php` if your MySQL password is not empty.

## Demo accounts
| Role | Username | Password |
|---|---|---|
| Admin | admin | Admin@123 |
| User | staff | User@123 |

## Features vs. requirements
| Requirement | Where |
|---|---|
| Create with client + server validation | `modules/create.php`, `modules/_form.php`, `assets/js/validation.js`, `validate_asset()` in `includes/functions.php` |
| Read: advanced JOIN, search, filter, pagination | `modules/dashboard.php`, `includes/asset_query.php` (5 tables joined) |
| Update | `modules/edit.php` |
| Delete (safe) | `modules/delete.php`: POST only, CSRF token, confirm dialog, admin only |
| CSV / PDF export | `export/csv.php`, `export/pdf.php` (respects current filters) |
| Prepared statements | PDO with real prepared statements everywhere (`config/db.php`) |
| Password hashing | `password_hash()` / `password_verify()` in `register.php`, `login.php` |
| Role-based access | `require_admin()` in `includes/auth.php`; admin-only delete, Users page, Audit log |
| Documentation | `docs/` (ERD, data dictionary, normalization) |

## Roles
- **Admin:** everything, including delete, user roles, and the audit log.
- **User:** view, add, edit, and export assets.

## Optional: real PDF download
The PDF export opens a print-ready page (use Print > Save as PDF). For a direct PDF file download, run this inside the project folder:

    composer require dompdf/dompdf

`export/pdf.php` detects `vendor/autoload.php` and switches to Dompdf automatically.

## Folder structure
    config/     database connection
    includes/   auth, helpers, layout, shared query
    modules/    asset CRUD pages
    export/     CSV and PDF reports
    admin/      user management, audit log
    assets/     CSS and JS
    database/   assettrack.sql
    docs/       ERD, data dictionary, normalization
