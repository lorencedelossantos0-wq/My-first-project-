<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/asset_query.php';
require_login();

const PER_PAGE = 8;
[$whereSql, $params, $f] = asset_filters();

// Total for pagination
$stmt = $pdo->prepare(ASSET_COUNT . $whereSql);
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$page  = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
$offset = ($page - 1) * PER_PAGE;

// Page of rows (LIMIT/OFFSET are ints we computed, so they are safe to inline)
$stmt = $pdo->prepare(ASSET_SELECT . $whereSql . ' ORDER BY a.asset_id DESC LIMIT ' . PER_PAGE . ' OFFSET ' . $offset);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Summary counts by status
$summary = $pdo->query('SELECT status, COUNT(*) AS n FROM assets GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);

$categories = lookup($pdo, 'categories', 'category_id');
$locations  = lookup($pdo, 'locations', 'location_id');

// Keep the filters in pagination/export links
$qs = fn(array $extra = []) => http_build_query(array_filter(array_merge($f, $extra), fn($v) => $v !== '' && $v !== 0));

$pageTitle = 'Assets';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head">
  <h1>Assets</h1>
  <div class="actions">
    <a class="btn" href="../export/csv.php?<?= $qs() ?>">Export CSV</a>
    <a class="btn" href="../export/pdf.php?<?= $qs() ?>" target="_blank" rel="noopener">Export PDF</a>
    <a class="btn primary" href="create.php">Add asset</a>
  </div>
</div>

<ul class="summary" aria-label="Assets by status">
  <?php foreach (ASSET_STATUSES as $s): ?>
    <li><a href="?status=<?= urlencode($s) ?>"><strong><?= (int)($summary[$s] ?? 0) ?></strong> <?= e($s) ?></a></li>
  <?php endforeach; ?>
</ul>

<form class="filters" method="get" role="search">
  <input type="search" name="q" placeholder="Search tag, name, serial, or custodian" value="<?= e($f['q']) ?>" aria-label="Search">
  <select name="category" aria-label="Category">
    <option value="0">All categories</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['id'] ?>" <?= $f['category'] == $c['id'] ? 'selected' : '' ?>><?= e($c['label']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="location" aria-label="Location">
    <option value="0">All locations</option>
    <?php foreach ($locations as $l): ?>
      <option value="<?= $l['id'] ?>" <?= $f['location'] == $l['id'] ? 'selected' : '' ?>><?= e($l['label']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="status" aria-label="Status">
    <option value="">All statuses</option>
    <?php foreach (ASSET_STATUSES as $s): ?>
      <option <?= $f['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn primary" type="submit">Apply</button>
  <a class="btn" href="dashboard.php">Reset</a>
</form>

<p class="muted"><?= $total ?> asset<?= $total === 1 ? '' : 's' ?> found</p>

<div class="table-wrap">
<table>
  <thead>
    <tr><th>Tag</th><th>Name</th><th>Category</th><th>Location</th><th>Custodian</th><th class="num">Cost</th><th>Status</th><th><span class="sr-only">Actions</span></th></tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?>
    <tr><td colspan="8" class="empty">No assets match these filters. Try clearing the search or <a href="create.php">add a new asset</a>.</td></tr>
  <?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['asset_tag']) ?></td>
      <td><?= e($r['name']) ?><?php if ($r['serial_no']): ?><br><small class="muted">S/N <?= e($r['serial_no']) ?></small><?php endif; ?></td>
      <td><?= e($r['category']) ?></td>
      <td><?= e($r['location']) ?></td>
      <td><?= $r['custodian'] ? e($r['custodian']) . '<br><small class="muted">' . e($r['department']) . '</small>' : '<span class="muted">Unassigned</span>' ?></td>
      <td class="num">&#8369;<?= number_format((float)$r['purchase_cost'], 2) ?></td>
      <td><span class="badge s-<?= strtolower(str_replace(' ', '-', $r['status'])) ?>"><?= e($r['status']) ?></span></td>
      <td class="row-actions">
        <a href="edit.php?id=<?= (int)$r['asset_id'] ?>">Edit</a>
        <?php if (is_admin()): ?>
        <form method="post" action="delete.php" data-confirm="Delete <?= e($r['asset_tag']) ?>? This cannot be undone.">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$r['asset_id'] ?>">
          <button type="submit" class="link danger">Delete</button>
        </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pagination">
  <?php if ($page > 1): ?><a href="?<?= $qs(['page' => $page - 1]) ?>">Previous</a><?php endif; ?>
  <?php for ($i = 1; $i <= $pages; $i++): ?>
    <a href="?<?= $qs(['page' => $i]) ?>" <?= $i === $page ? 'aria-current="page" class="current"' : '' ?>><?= $i ?></a>
  <?php endfor; ?>
  <?php if ($page < $pages): ?><a href="?<?= $qs(['page' => $page + 1]) ?>">Next</a><?php endif; ?>
</nav>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
