<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();                       // only admins may delete

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/modules/dashboard.php'); // never delete through a GET link
}
verify_csrf();

$id = (int)($_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT asset_tag FROM assets WHERE asset_id = ?');
$stmt->execute([$id]);
$tag = $stmt->fetchColumn();

if ($tag === false) {
    flash('error', 'That asset no longer exists.');
} else {
    // Log first: audit_logs.asset_id is set to NULL by the FK when the asset row is removed,
    // so the details text keeps the tag for the record.
    audit($pdo, 'DELETE', $id, 'Deleted asset ' . $tag);
    $pdo->prepare('DELETE FROM assets WHERE asset_id = ?')->execute([$id]);
    flash('success', 'Asset ' . $tag . ' deleted.');
}
redirect('/modules/dashboard.php');
