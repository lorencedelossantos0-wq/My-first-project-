// Client-side validation. This is for convenience only: the server re-validates everything.
(function () {
  'use strict';

  function fieldError(input, message) {
    var next = input.parentElement.querySelector('.field-error.js');
    if (message) {
      input.classList.add('invalid');
      input.setAttribute('aria-invalid', 'true');
      if (!next) {
        next = document.createElement('small');
        next.className = 'field-error js';
        input.insertAdjacentElement('afterend', next);
      }
      next.textContent = message;
    } else {
      input.classList.remove('invalid');
      input.removeAttribute('aria-invalid');
      if (next) next.remove();
    }
  }

  function messageFor(input) {
    var v = input.validity;
    if (v.valueMissing)    return 'This field is required.';
    if (v.typeMismatch)    return 'Enter a valid ' + (input.type === 'email' ? 'email address.' : 'value.');
    if (v.tooShort)        return 'Use at least ' + input.minLength + ' characters.';
    if (v.patternMismatch) return input.title || 'The format is not valid.';
    if (v.rangeUnderflow || v.rangeOverflow) return 'Value is out of range.';
    if (v.stepMismatch)    return 'Use up to two decimal places.';
    return '';
  }

  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    var status = form.querySelector('[name=status]');
    var custodian = form.querySelector('[name=custodian_id]');

    function check(input) {
      var msg = input.checkValidity() ? '' : messageFor(input);
      // Rule: In Use requires a custodian
      if (!msg && custodian && input === custodian && status && status.value === 'In Use' && custodian.value === '0') {
        msg = 'Assign a custodian when the status is In Use.';
      }
      fieldError(input, msg);
      return !msg;
    }

    form.addEventListener('submit', function (ev) {
      var ok = true, first = null;
      form.querySelectorAll('input, select').forEach(function (el) {
        if (el.type === 'hidden') return;
        if (!check(el)) { ok = false; first = first || el; }
      });
      // Password confirmation on the register form
      var pw = form.querySelector('[name=password]'), cf = form.querySelector('[name=confirm]');
      if (pw && cf && pw.value !== cf.value) { fieldError(cf, 'Passwords do not match.'); ok = false; first = first || cf; }
      if (!ok) { ev.preventDefault(); first.focus(); }
    });

    form.querySelectorAll('input, select').forEach(function (el) {
      el.addEventListener('blur', function () { if (el.type !== 'hidden') check(el); });
    });
    if (status && custodian) status.addEventListener('change', function () { check(custodian); });
  });

  // Confirm before destructive actions
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (!window.confirm(form.getAttribute('data-confirm'))) ev.preventDefault();
    });
  });
})();
