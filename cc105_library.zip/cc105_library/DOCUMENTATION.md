# CC 105 Final Project Documentation

## Project Title

Library Management System

## Objective

The system manages a library book catalog with its authors and categories using MySQL and PHP in Laragon.

## Sample Data

The main dataset is the `books` table: **10 columns and 1,000 rows**. It is connected by foreign keys to two small lookup tables, `authors` (50 rows) and `categories` (10 rows).

---

## Entities

### 1. Authors

Primary key: `author_id`

Attributes: `author_id`, `full_name`, `email`

### 2. Categories

Primary key: `category_id`

Attributes: `category_id`, `name`

### 3. Books (main dataset - 10 columns)

Primary key: `book_id`

Foreign keys: `author_id`, `category_id`

| # | Column | Type |
|---|--------|------|
| 1 | `book_id` | INT, PK, auto increment |
| 2 | `isbn` | VARCHAR(20), unique |
| 3 | `title` | VARCHAR(180) |
| 4 | `author_id` | INT, FK to `authors` |
| 5 | `category_id` | INT, FK to `categories` |
| 6 | `published_year` | YEAR |
| 7 | `language` | VARCHAR(30) |
| 8 | `pages` | INT |
| 9 | `price` | DECIMAL(10,2) |
| 10 | `stock` | INT |

---

## Entity Relationship Diagram

```text
AUTHORS                      CATEGORIES
author_id PK                 category_id PK
full_name                    name
email                             |
     |                            |
     | 1-to-many                  | 1-to-many
     |                            |
     +-----------> BOOKS <--------+
                   book_id PK
                   isbn
                   title
                   author_id FK
                   category_id FK
                   published_year
                   language
                   pages
                   price
                   stock
```

---

## Relationship Description

- One author may write many books.
- Each book belongs to one author.
- One category may contain many books.
- Each book belongs to one category.

---

## Normalization

### First Normal Form

- Each column contains atomic values.
- There are no repeating groups.
- Each table has a primary key.

### Second Normal Form

- It is already in 1NF.
- Every non-key attribute depends on the whole primary key (all primary keys are single columns, so there are no partial dependencies).

### Third Normal Form

- It is already in 2NF.
- Non-key attributes do not depend on other non-key attributes.
- Author information is stored only in `authors`.
- Category information is stored only in `categories`.
- `books` stores only `author_id` and `category_id`, not the author or category names, which avoids duplicate data.

---

## CRUD Functions

- **Create:** add a new book.
- **Read:** display books (25 per page) with author and category names; display report summaries.
- **Update:** edit book information.
- **Delete:** delete a book.

---

## Advanced SQL Queries

The system uses `INNER JOIN` across three tables, `WHERE` for filtering, and `COUNT()`, `AVG()`, `SUM()`, `GROUP BY`, and `HAVING` for reports.

### Aggregation example

```sql
SELECT
    c.name,
    COUNT(b.book_id),
    AVG(b.price),
    SUM(b.stock)
FROM categories c
LEFT JOIN books b
    ON c.category_id = b.category_id
GROUP BY c.category_id, c.name
HAVING COUNT(b.book_id) > 0;
```

### Join example

```sql
SELECT
    b.book_id,
    b.title,
    a.full_name AS author,
    c.name AS category,
    b.price
FROM books b
INNER JOIN authors a
    ON b.author_id = a.author_id
INNER JOIN categories c
    ON b.category_id = c.category_id
WHERE b.published_year >= 2015;
```
