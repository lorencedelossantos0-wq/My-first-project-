# Library Management System (CC 105)

## Setup (Laragon)
1. Copy this folder to `C:\laragon\www\cc105_library`.
2. Open Laragon and click **Start All**.
3. Open HeidiSQL or phpMyAdmin (`http://localhost/phpmyadmin`) and run the whole `database.sql`.
   It creates the `cc105_library` database and fills `books` with 1,000 rows (10 columns), linked to 50 authors and 10 categories.
4. If your MySQL root has a password, set it in `config.php` (`$password`).
5. Open `http://localhost/cc105_library/` (reports: `/reports.php`).

## Demo sequence (5-10 min)
1. Database: show `authors`, `categories`, `books` and the PK/FK links.
2. Create: add a new book.
3. Read: browse the books list with author/category names and pagination.
4. Update: click Edit, change the title or price, save.
5. Delete: add a test book, then delete it.
6. Advanced SQL: open `reports.php` (totals, low stock, category aggregation, 3-table join with WHERE).
