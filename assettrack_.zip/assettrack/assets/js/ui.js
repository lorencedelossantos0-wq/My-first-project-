// AssetTrack UI behaviour: theme, mobile menu, password reveal, count-up numbers, dismissible alerts.
// Purely presentational. Form validation lives in validation.js.
(function () {
  'use strict';

  var root = document.documentElement;
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Theme (light / dark), remembered in this browser ---- */
  function currentTheme() {
    var t = root.getAttribute('data-theme');
    if (t) return t;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  document.querySelectorAll('.theme-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var next = currentTheme() === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('at-theme', next); } catch (e) {}
    });
  });

  /* ---- Mobile sidebar ---- */
  var toggle = document.querySelector('.nav-toggle');
  function setNav(open) {
    document.body.classList.toggle('nav-open', open);
    if (toggle) {
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }
  }
  if (toggle) toggle.addEventListener('click', function () { setNav(!document.body.classList.contains('nav-open')); });
  document.querySelectorAll('[data-nav-close]').forEach(function (el) { el.addEventListener('click', function () { setNav(false); }); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') setNav(false); });

  /* ---- Show / hide password ---- */
  var eyeOn  = '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
  var eyeOff = '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.53 13.53 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><path d="m2 2 20 20"/></svg>';
  document.querySelectorAll('.input-wrap input[type=password]').forEach(function (input) {
    var wrap = input.closest('.input-wrap');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-toggle';
    btn.setAttribute('aria-label', 'Show password');
    btn.innerHTML = eyeOn;
    // keep focus in the field so the validator does not fire when the eye is clicked
    btn.addEventListener('mousedown', function (ev) { ev.preventDefault(); });
    btn.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.innerHTML = show ? eyeOff : eyeOn;
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
    wrap.classList.add('has-toggle');
    wrap.appendChild(btn);
  });

  /* ---- Count-up for the summary numbers (final value is already in the HTML) ---- */
  if (!reduceMotion) {
    document.querySelectorAll('[data-count]').forEach(function (el) {
      var end = parseInt(el.getAttribute('data-count'), 10);
      if (!isFinite(end) || end <= 0) return;
      var dur = 700, start = null;
      el.textContent = '0';
      function tick(ts) {
        if (start === null) start = ts;
        var p = Math.min(1, (ts - start) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = String(Math.round(end * eased));
        if (p < 1) requestAnimationFrame(tick); else el.textContent = String(end);
      }
      requestAnimationFrame(tick);
    });
  }

  /* ---- Alerts: dismiss button, success/info fade out by themselves ---- */
  function closeAlert(el) {
    if (!el || !el.parentNode) return;
    el.classList.add('is-leaving');
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, reduceMotion ? 0 : 320);
  }
  document.querySelectorAll('.alert').forEach(function (el) {
    var close = el.querySelector('.alert-close');
    if (close) close.addEventListener('click', function () { closeAlert(el); });
    if (el.classList.contains('alert-success') || el.classList.contains('alert-info')) {
      setTimeout(function () { closeAlert(el); }, 6000);
    }
  });

  /* ---- Busy state on a valid submit (does not block the submit) ---- */
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (ev.defaultPrevented) return;
      var btn = form.querySelector('button[type=submit]');
      if (btn) btn.classList.add('is-busy');
    });
  });
  window.addEventListener('pageshow', function () {
    document.querySelectorAll('.is-busy').forEach(function (b) { b.classList.remove('is-busy'); });
  });
})();
