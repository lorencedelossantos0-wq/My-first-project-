<?php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'assettrack';
const DB_USER = 'root';
const DB_PASS = '';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Database error | AssetTrack</title>'
       . '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b2431;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#e7eef5}'
       . '.box{max-width:460px;margin:24px;padding:36px 32px;border-radius:20px;background:#111d2a;border:1px solid #1d2d3d;box-shadow:0 28px 70px -20px rgba(0,0,0,.8);text-align:center}'
       . '.ico{width:60px;height:60px;margin:0 auto 16px;border-radius:18px;display:grid;place-items:center;background:rgba(240,68,56,.14);color:#ff9d95;font-size:28px;font-weight:700}'
       . 'h1{margin:0 0 8px;font-size:1.4rem}p{margin:0;color:#9db0c2;line-height:1.55}</style></head>'
       . '<body><div class="box"><div class="ico">!</div><h1>Database connection failed</h1>'
       . '<p>Database connection failed. Check config/db.php and that assettrack.sql is imported.</p></div></body></html>');
}
