<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('/modules/dashboard.php');

$errors = [];
$old = ['full_name' => '', 'username' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $old['full_name'] = trim($_POST['full_name'] ?? '');
    $old['username']  = trim($_POST['username'] ?? '');
    $old['email']     = trim($_POST['email'] ?? '');
    $password         = $_POST['password'] ?? '';
    $confirm          = $_POST['confirm'] ?? '';

    if (mb_strlen($old['full_name']) < 2 || mb_strlen($old['full_name']) > 100) $errors['full_name'] = 'Enter your full name (2-100 characters).';
    if (!preg_match('/^[A-Za-z0-9_]{4,40}$/', $old['username'])) $errors['username'] = 'Username: 4-40 letters, numbers, or underscores.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email address.';
    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors['password'] = 'Password needs 8+ characters with at least one letter and one number.';
    }
    if ($password !== $confirm) $errors['confirm'] = 'Passwords do not match.';

    if (!$errors) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = ? OR email = ?');
        $stmt->execute([$old['username'], $old['email']]);
        if ($stmt->fetchColumn() > 0) {
            $errors['username'] = 'Username or email is already registered.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO users (full_name, username, email, password_hash, role) VALUES (?, ?, ?, ?, "user")');
        $stmt->execute([$old['full_name'], $old['username'], $old['email'], password_hash($password, PASSWORD_DEFAULT)]);
        flash('success', 'Account created. You can log in now.');
        redirect('/login.php');
    }
}

$pageTitle = 'Create account';
require __DIR__ . '/includes/header.php';
$err = fn($k) => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';
?>
<section class="auth-card" data-anim>
  <div class="auth-head">
    <h1>Create account</h1>
    <p class="muted">Register a staff account to start tracking assets.</p>
  </div>
  <form method="post" novalidate data-validate>
    <?= csrf_field() ?>
    <label>Full name
      <span class="input-wrap"><?= icon('user') ?><input type="text" name="full_name" required minlength="2" maxlength="100" value="<?= e($old['full_name']) ?>"></span>
      <?= $err('full_name') ?>
    </label>
    <label>Username
      <span class="input-wrap"><?= icon('tag') ?><input type="text" name="username" required pattern="[A-Za-z0-9_]{4,40}" title="4-40 letters, numbers, or underscores" value="<?= e($old['username']) ?>"></span>
      <?= $err('username') ?>
    </label>
    <label>Email
      <span class="input-wrap"><?= icon('mail') ?><input type="email" name="email" required value="<?= e($old['email']) ?>"></span>
      <?= $err('email') ?>
    </label>
    <div class="pair">
      <label>Password
        <span class="input-wrap"><?= icon('lock') ?><input type="password" name="password" required minlength="8" autocomplete="new-password"></span>
        <?= $err('password') ?>
      </label>
      <label>Confirm password
        <span class="input-wrap"><?= icon('lock') ?><input type="password" name="confirm" required autocomplete="new-password"></span>
        <?= $err('confirm') ?>
      </label>
    </div>
    <button class="btn primary block" type="submit"><?= icon('check') ?>Create account</button>
  </form>
  <p class="muted auth-alt">Already registered? <a href="login.php">Log in</a></p>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
