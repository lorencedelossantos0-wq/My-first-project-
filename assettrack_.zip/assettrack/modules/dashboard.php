<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/asset_query.php';
require_login();

const PER_PAGE = 8;
[$whereSql, $params, $f] = asset_filters();

$stmt = $pdo->prepare(ASSET_COUNT . $whereSql);
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$page  = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
$offset = ($page - 1) * PER_PAGE;

$stmt = $pdo->prepare(ASSET_SELECT . $whereSql . ' ORDER BY a.asset_id DESC LIMIT ' . PER_PAGE . ' OFFSET ' . $offset);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$summary = $pdo->query('SELECT status, COUNT(*) AS n FROM assets GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);

$categories = lookup($pdo, 'categories', 'category_id');
$locations  = lookup($pdo, 'locations', 'location_id');

$qs = fn(array $extra = []) => http_build_query(array_filter(array_merge($f, $extra), fn($v) => $v !== '' && $v !== 0));

$pageTitle = 'Assets';
require __DIR__ . '/../includes/header.php';
?>
<?php
$grand = array_sum(array_map('intval', $summary));
$statusIcon = ['Available' => 'check', 'In Use' => 'user-check', 'Under Repair' => 'wrench', 'Retired' => 'archive'];
$tone = fn(string $s) => strtolower(str_replace(' ', '-', $s));
?>
<div class="page-head">
  <div>
    <h1>Assets</h1>
    <p class="sub">Welcome back, <?= e($_SESSION['full_name']) ?>. Here is what is in your inventory.</p>
  </div>
  <div class="actions">
    <a class="btn" href="../export/csv.php?<?= $qs() ?>"><?= icon('download') ?>Export CSV</a>
    <a class="btn" href="../export/pdf.php?<?= $qs() ?>" target="_blank" rel="noopener"><?= icon('file-text') ?>Export PDF</a>
    <a class="btn primary" href="create.php"><?= icon('plus') ?>Add asset</a>
  </div>
</div>

<ul class="summary stats" aria-label="Assets by status">
  <li class="stat tone-total <?= $f['status'] === '' ? 'is-active' : '' ?>">
    <a href="dashboard.php"><span class="stat-ico"><?= icon('layers') ?></span><span class="stat-body"><strong data-count="<?= $grand ?>"><?= $grand ?></strong><span>All assets</span></span></a>
  </li>
  <?php foreach (ASSET_STATUSES as $s): ?>
    <li class="stat tone-<?= $tone($s) ?> <?= $f['status'] === $s ? 'is-active' : '' ?>">
      <a href="?status=<?= urlencode($s) ?>"><span class="stat-ico"><?= icon($statusIcon[$s]) ?></span><span class="stat-body"><strong data-count="<?= (int)($summary[$s] ?? 0) ?>"><?= (int)($summary[$s] ?? 0) ?></strong> <span><?= e($s) ?></span></span></a>
    </li>
  <?php endforeach; ?>
</ul>
<?php if ($grand > 0): ?>
<div class="dist" role="img" aria-label="Share of assets by status">
  <?php foreach (ASSET_STATUSES as $s): $n = (int)($summary[$s] ?? 0); if ($n === 0) continue; ?>
    <span class="seg tone-<?= $tone($s) ?>" style="--n: <?= $n ?>" title="<?= e($s) ?>: <?= $n ?>"></span>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<form class="filters card-flat" method="get" role="search">
  <span class="input-wrap search"><?= icon('search') ?><input type="search" name="q" placeholder="Search tag, name, serial, or custodian" value="<?= e($f['q']) ?>" aria-label="Search"></span>
  <select name="category" aria-label="Category">
    <option value="0">All categories</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['id'] ?>" <?= $f['category'] == $c['id'] ? 'selected' : '' ?>><?= e($c['label']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="location" aria-label="Location">
    <option value="0">All locations</option>
    <?php foreach ($locations as $l): ?>
      <option value="<?= $l['id'] ?>" <?= $f['location'] == $l['id'] ? 'selected' : '' ?>><?= e($l['label']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="status" aria-label="Status">
    <option value="">All statuses</option>
    <?php foreach (ASSET_STATUSES as $s): ?>
      <option <?= $f['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn primary" type="submit"><?= icon('search') ?>Apply</button>
  <a class="btn" href="dashboard.php"><?= icon('refresh') ?>Reset</a>
</form>

<p class="result-count muted"><?= $total ?> asset<?= $total === 1 ? '' : 's' ?> found</p>

<div class="table-wrap">
<table class="data assets">
  <thead>
    <tr><th>Tag</th><th>Name</th><th>Category</th><th>Location</th><th>Custodian</th><th class="num">Cost</th><th>Status</th><th><span class="sr-only">Actions</span></th></tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?>
    <tr><td colspan="8" class="empty"><span class="empty-ico"><?= icon('inbox') ?></span><strong>Nothing here yet</strong><br>No assets match these filters. Try clearing the search or <a href="create.php">add a new asset</a>.</td></tr>
  <?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><span class="tag"><?= e($r['asset_tag']) ?></span></td>
      <td><span class="cell-main"><?= e($r['name']) ?></span><?php if ($r['serial_no']): ?><small class="muted">S/N <?= e($r['serial_no']) ?></small><?php endif; ?></td>
      <td><?= e($r['category']) ?></td>
      <td><span class="loc"><?= icon('map-pin') ?><?= e($r['location']) ?></span></td>
      <td><?php if ($r['custodian']): ?><span class="person"><span class="avatar"><?= e(initials($r['custodian'])) ?></span><span><span class="cell-main"><?= e($r['custodian']) ?></span><small class="muted"><?= e($r['department']) ?></small></span></span><?php else: ?><span class="muted">Unassigned</span><?php endif; ?></td>
      <td class="num money">&#8369;<?= number_format((float)$r['purchase_cost'], 2) ?></td>
      <td><span class="badge s-<?= $tone($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td class="row-actions">
        <a class="row-btn icon-only" href="edit.php?id=<?= (int)$r['asset_id'] ?>" title="Edit <?= e($r['asset_tag']) ?>"><?= icon('pencil') ?><span class="sr-only">Edit</span></a>
        <?php if (is_admin()): ?>
        <form method="post" action="delete.php" data-confirm="Delete <?= e($r['asset_tag']) ?>? This cannot be undone.">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$r['asset_id'] ?>">
          <button type="submit" class="row-btn danger icon-only" title="Delete <?= e($r['asset_tag']) ?>"><?= icon('trash') ?><span class="sr-only">Delete</span></button>
        </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pagination">
  <?php if ($page > 1): ?><a class="pg-step" href="?<?= $qs(['page' => $page - 1]) ?>"><?= icon('chev-left') ?>Previous</a><?php endif; ?>
  <?php for ($i = 1; $i <= $pages; $i++): ?>
    <a href="?<?= $qs(['page' => $i]) ?>" <?= $i === $page ? 'aria-current="page" class="current"' : '' ?>><?= $i ?></a>
  <?php endfor; ?>
  <?php if ($page < $pages): ?><a class="pg-step" href="?<?= $qs(['page' => $page + 1]) ?>">Next<?= icon('chev-right') ?></a><?php endif; ?>
</nav>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
