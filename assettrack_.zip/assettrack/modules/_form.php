<?php
$categories = lookup($pdo, 'categories', 'category_id');
$locations  = lookup($pdo, 'locations', 'location_id');
$suppliers  = lookup($pdo, 'suppliers', 'supplier_id');
$employees  = lookup($pdo, 'employees', 'employee_id', 'full_name');
$err = fn($k) => isset($errors[$k]) ? '<small class="field-error">' . e($errors[$k]) . '</small>' : '';
$opts = function (array $list, $selected, string $blank = '') {
    $html = $blank !== '' ? '<option value="0">' . e($blank) . '</option>' : '<option value="">Select...</option>';
    foreach ($list as $o) {
        $html .= '<option value="' . $o['id'] . '"' . ((int)$selected === (int)$o['id'] ? ' selected' : '') . '>' . e($o['label']) . '</option>';
    }
    return $html;
};
?>
<form method="post" class="card form-grid" novalidate data-validate data-anim>
  <?= csrf_field() ?>

  <h2 class="form-section"><span><?= icon('tag') ?></span>Identification</h2>
  <label>Asset tag
    <span class="input-wrap"><input type="text" name="asset_tag" required pattern="[A-Za-z0-9\-]{3,30}" title="3-30 letters, numbers, or hyphens" value="<?= e($data['asset_tag']) ?>"></span>
    <?= $err('asset_tag') ?>
  </label>
  <label>Name
    <span class="input-wrap"><input type="text" name="name" required minlength="2" maxlength="120" value="<?= e($data['name']) ?>"></span>
    <?= $err('name') ?>
  </label>
  <label>Serial number <span class="muted">(optional)</span>
    <span class="input-wrap"><input type="text" name="serial_no" maxlength="60" value="<?= e($data['serial_no']) ?>"></span>
    <?= $err('serial_no') ?>
  </label>

  <h2 class="form-section"><span><?= icon('map-pin') ?></span>Classification &amp; location</h2>
  <label>Category
    <select name="category_id" required><?= $opts($categories, $data['category_id']) ?></select>
    <?= $err('category_id') ?>
  </label>
  <label>Location
    <select name="location_id" required><?= $opts($locations, $data['location_id']) ?></select>
    <?= $err('location_id') ?>
  </label>
  <label>Supplier <span class="muted">(optional)</span>
    <select name="supplier_id"><?= $opts($suppliers, $data['supplier_id'], 'None') ?></select>
  </label>

  <h2 class="form-section"><span><?= icon('user-check') ?></span>Assignment &amp; status</h2>
  <label>Custodian <span class="muted">(required when In Use)</span>
    <select name="custodian_id"><?= $opts($employees, $data['custodian_id'], 'Unassigned') ?></select>
    <?= $err('custodian_id') ?>
  </label>
  <label>Status
    <select name="status" required>
      <?php foreach (ASSET_STATUSES as $s): ?>
        <option <?= $data['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
      <?php endforeach; ?>
    </select>
    <?= $err('status') ?>
  </label>

  <h2 class="form-section"><span><?= icon('file-text') ?></span>Purchase details</h2>
  <label>Purchase date
    <span class="input-wrap"><input type="date" name="purchase_date" required max="<?= date('Y-m-d') ?>" value="<?= e($data['purchase_date']) ?>"></span>
    <?= $err('purchase_date') ?>
  </label>
  <label>Purchase cost (PHP)
    <span class="input-wrap prefix"><span class="affix">&#8369;</span><input type="number" name="purchase_cost" required min="0" max="99999999.99" step="0.01" value="<?= e((string)$data['purchase_cost']) ?>"></span>
    <?= $err('purchase_cost') ?>
  </label>

  <div class="form-actions">
    <button class="btn primary" type="submit"><?= icon('check') ?><?= e($submitLabel) ?></button>
    <a class="btn" href="dashboard.php">Cancel</a>
  </div>
</form>
