<?php
$pageTitle = $pageTitle ?? 'AssetTrack';
$isGuest   = !is_logged_in();

// Which sidebar link is highlighted (edit.php belongs to the Assets section).
$navMap = ['dashboard' => 'assets', 'edit' => 'assets', 'create' => 'create', 'users' => 'users', 'audit_log' => 'audit'];
$navKey = $navMap[basename($_SERVER['SCRIPT_NAME'] ?? '', '.php')] ?? '';
$navCls = fn(string $k) => 'nav-link' . ($navKey === $k ? ' is-active' : '');
$navCur = fn(string $k) => $navKey === $k ? ' aria-current="page"' : '';
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <title><?= e($pageTitle) ?> | AssetTrack</title>
  <script>try{var t=localStorage.getItem('at-theme');if(t){document.documentElement.setAttribute('data-theme',t);}}catch(e){}</script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&family=Sora:wght@600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<?php if ($isGuest): ?>
<body class="auth-body">
<div class="auth-shell">
  <aside class="auth-art" aria-hidden="true">
    <span class="blob b1"></span><span class="blob b2"></span><span class="blob b3"></span>
    <div class="auth-art-inner">
      <div class="brand brand-lg">
        <span class="brand-mark"><?= icon('package') ?></span>
        <span class="brand-text">AssetTrack<small>Asset management system</small></span>
      </div>
      <h2>Know where every<br>asset is, and who has it.</h2>
      <p>Track laptops, printers, network gear and furniture from purchase to retirement, with a full audit trail.</p>
      <ul class="auth-chips">
        <li class="chip tone-available"><i></i>Available</li>
        <li class="chip tone-in-use"><i></i>In Use</li>
        <li class="chip tone-under-repair"><i></i>Under Repair</li>
        <li class="chip tone-retired"><i></i>Retired</li>
      </ul>
    </div>
  </aside>
  <main class="auth-main">
    <button type="button" class="icon-btn theme-toggle auth-theme" aria-label="Toggle dark mode" title="Toggle dark mode">
      <?= icon('moon', 'i-moon') ?><?= icon('sun', 'i-sun') ?>
    </button>
    <div class="auth-stack">
      <div class="auth-mobile-brand brand"><span class="brand-mark"><?= icon('package') ?></span><span class="brand-text">AssetTrack</span></div>
      <?php show_flash(); ?>
<?php else: ?>
<body class="app-body">
<div class="app">
  <aside class="sidebar" id="sidebar" aria-label="Sidebar">
    <a class="brand" href="<?= BASE_URL ?>/modules/dashboard.php">
      <span class="brand-mark"><?= icon('package') ?></span>
      <span class="brand-text">AssetTrack<small>Asset management</small></span>
    </a>
    <nav class="side-nav" aria-label="Main">
      <p class="nav-label">Workspace</p>
      <a class="<?= $navCls('assets') ?>" href="<?= BASE_URL ?>/modules/dashboard.php"<?= $navCur('assets') ?>><?= icon('layers') ?><span>Assets</span></a>
      <a class="<?= $navCls('create') ?>" href="<?= BASE_URL ?>/modules/create.php"<?= $navCur('create') ?>><?= icon('plus') ?><span>Add asset</span></a>
      <?php if (is_admin()): ?>
      <p class="nav-label nav-label-admin"><?= icon('shield-check') ?>Administration</p>
      <a class="<?= $navCls('users') ?> admin-link" href="<?= BASE_URL ?>/admin/users.php"<?= $navCur('users') ?>><?= icon('users') ?><span>Users</span></a>
      <a class="<?= $navCls('audit') ?> admin-link" href="<?= BASE_URL ?>/admin/audit_log.php"<?= $navCur('audit') ?>><?= icon('clipboard') ?><span>Audit log</span></a>
      <?php endif; ?>
    </nav>
    <div class="side-foot">
      <div class="whoami">
        <span class="avatar avatar-lg <?= is_admin() ? 'is-admin' : '' ?>"><?= e(initials($_SESSION['full_name'])) ?></span>
        <div class="who-text">
          <strong><?= e($_SESSION['full_name']) ?></strong>
          <em class="role role-<?= e($_SESSION['role']) ?>"><?= e($_SESSION['role']) ?></em>
        </div>
      </div>
      <a class="logout" href="<?= BASE_URL ?>/logout.php"><?= icon('log-out') ?>Log out</a>
    </div>
  </aside>
  <div class="scrim" data-nav-close></div>
  <div class="content">
    <header class="topbar">
      <button type="button" class="icon-btn nav-toggle" aria-label="Open menu" aria-controls="sidebar" aria-expanded="false"><?= icon('menu') ?></button>
      <div class="crumbs"><span>AssetTrack</span><span class="sep">/</span><strong><?= e($pageTitle) ?></strong></div>
      <div class="top-actions">
        <?php if (is_admin()): ?><span class="admin-chip"><?= icon('shield-check') ?>Admin mode</span><?php endif; ?>
        <button type="button" class="icon-btn theme-toggle" aria-label="Toggle dark mode" title="Toggle dark mode">
          <?= icon('moon', 'i-moon') ?><?= icon('sun', 'i-sun') ?>
        </button>
      </div>
    </header>
    <main class="page">
<?php show_flash(); ?>
<?php endif; ?>
