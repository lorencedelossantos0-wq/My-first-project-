<?php if (!empty($isGuest)): ?>
      <p class="auth-foot">AssetTrack &middot; CC 106 Final Project</p>
    </div>
  </main>
</div>
<?php else: ?>
    </main>
    <footer class="foot">AssetTrack &middot; CC 106 Final Project</footer>
  </div>
</div>
<?php endif; ?>
<script src="<?= BASE_URL ?>/assets/js/validation.js"></script>
<script src="<?= BASE_URL ?>/assets/js/ui.js"></script>
</body>
</html>
