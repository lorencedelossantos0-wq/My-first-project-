<?php

require_once __DIR__ . '/icons.php';

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function verify_csrf(): void {
    $sent = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        error_page(403, 'Form expired', 'Invalid or expired form token. Go back and try again.');
    }
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

// One alert component used by flash messages and inline form errors (icon + message + dismiss button).
function alert_html(string $type, string $message): string {
    $ico = ['success' => 'check-circle', 'error' => 'alert-circle', 'info' => 'info'][$type] ?? 'info';
    return '<div class="alert alert-' . e($type) . '" role="' . ($type === 'error' ? 'alert' : 'status') . '">'
         . '<span class="alert-ico">' . icon($ico) . '</span>'
         . '<span class="alert-msg">' . e($message) . '</span>'
         . '<button type="button" class="alert-close" aria-label="Dismiss message">' . icon('x') . '</button>'
         . '</div>';
}

function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        echo alert_html((string)$f['type'], (string)$f['message']);
    }
}

// Two-letter initials for avatar bubbles ("Maria Santos" -> "MS").
function initials(?string $name): string {
    $parts = preg_split('/\s+/u', trim((string)$name), -1, PREG_SPLIT_NO_EMPTY);
    if (!$parts) return '?';
    $first = mb_substr($parts[0], 0, 1);
    $last  = count($parts) > 1 ? mb_substr($parts[count($parts) - 1], 0, 1) : mb_substr($parts[0], 1, 1);
    return mb_strtoupper($first . $last);
}

// Styled full-page message (403, expired token, ...). Same text as before, now inside the app layout.
function error_page(int $code, string $title, string $message): void {
    http_response_code($code);
    $pageTitle = $title;
    require __DIR__ . '/header.php';
    echo '<section class="card state-card" data-anim>'
       . '<span class="state-ico">' . icon('lock') . '</span>'
       . '<h1>' . e($title) . '</h1>'
       . '<p class="muted">' . e($message) . '</p>'
       . '<a class="btn primary" href="' . e(BASE_URL) . '/index.php">' . icon('arrow-left') . 'Back to safety</a>'
       . '</section>';
    require __DIR__ . '/footer.php';
    exit;
}

function redirect(string $path): void {
    header('Location: ' . BASE_URL . $path);
    exit;
}

function audit(PDO $pdo, string $action, ?int $assetId, string $details): void {
    $stmt = $pdo->prepare('INSERT INTO audit_logs (user_id, asset_id, action, details) VALUES (?, ?, ?, ?)');
    $stmt->execute([$_SESSION['user_id'], $assetId, $action, $details]);
}

const ASSET_STATUSES = ['Available', 'In Use', 'Under Repair', 'Retired'];


function validate_asset(PDO $pdo, array $in, ?int $ignoreId = null): array {
    $errors = [];
    $d = [
        'asset_tag'     => strtoupper(trim($in['asset_tag'] ?? '')),
        'name'          => trim($in['name'] ?? ''),
        'serial_no'     => trim($in['serial_no'] ?? ''),
        'category_id'   => (int)($in['category_id'] ?? 0),
        'supplier_id'   => (int)($in['supplier_id'] ?? 0),
        'location_id'   => (int)($in['location_id'] ?? 0),
        'custodian_id'  => (int)($in['custodian_id'] ?? 0),
        'purchase_date' => trim($in['purchase_date'] ?? ''),
        'purchase_cost' => trim($in['purchase_cost'] ?? ''),
        'status'        => trim($in['status'] ?? ''),
    ];

    if (!preg_match('/^[A-Z0-9-]{3,30}$/', $d['asset_tag'])) {
        $errors['asset_tag'] = 'Asset tag must be 3-30 characters: letters, numbers, or hyphens.';
    } else {
        $sql = 'SELECT COUNT(*) FROM assets WHERE asset_tag = ?' . ($ignoreId ? ' AND asset_id <> ?' : '');
        $stmt = $pdo->prepare($sql);
        $stmt->execute($ignoreId ? [$d['asset_tag'], $ignoreId] : [$d['asset_tag']]);
        if ($stmt->fetchColumn() > 0) {
            $errors['asset_tag'] = 'That asset tag is already in use.';
        }
    }

    if (mb_strlen($d['name']) < 2 || mb_strlen($d['name']) > 120) {
        $errors['name'] = 'Name must be 2-120 characters.';
    }
    if ($d['serial_no'] !== '' && mb_strlen($d['serial_no']) > 60) {
        $errors['serial_no'] = 'Serial number is too long (60 max).';
    }

    foreach (['category_id' => 'categories', 'location_id' => 'locations'] as $field => $table) {
        $col = $table === 'categories' ? 'category_id' : 'location_id';
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE $col = ?");
        $stmt->execute([$d[$field]]);
        if (!$stmt->fetchColumn()) {
            $errors[$field] = 'Please choose a valid option.';
        }
    }

    $dt = DateTime::createFromFormat('Y-m-d', $d['purchase_date']);
    if (!$dt || $dt->format('Y-m-d') !== $d['purchase_date']) {
        $errors['purchase_date'] = 'Enter a valid date.';
    } elseif ($dt > new DateTime('today')) {
        $errors['purchase_date'] = 'Purchase date cannot be in the future.';
    }

    if (!is_numeric($d['purchase_cost']) || (float)$d['purchase_cost'] < 0 || (float)$d['purchase_cost'] > 99999999.99) {
        $errors['purchase_cost'] = 'Cost must be a number from 0 to 99,999,999.99.';
    }

    if (!in_array($d['status'], ASSET_STATUSES, true)) {
        $errors['status'] = 'Choose a valid status.';
    }

    // Business rule: an asset marked In Use must have a custodian.
    if ($d['status'] === 'In Use' && $d['custodian_id'] === 0) {
        $errors['custodian_id'] = 'Assign a custodian when the status is In Use.';
    }

    return [$errors, $d];
}

function lookup(PDO $pdo, string $table, string $idCol, string $nameCol = 'name'): array {
    // $table/$idCol come from code, never from user input.
    return $pdo->query("SELECT $idCol AS id, $nameCol AS label FROM $table ORDER BY $nameCol")->fetchAll();
}
