<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/asset_query.php';
require_login();

[$whereSql, $params, $f] = asset_filters();
$stmt = $pdo->prepare(ASSET_SELECT . $whereSql . ' ORDER BY a.asset_tag');
$stmt->execute($params);
$rows = $stmt->fetchAll();
audit($pdo, 'EXPORT', null, 'Exported PDF report');

$total = array_sum(array_column($rows, 'purchase_cost'));

// Quick totals for the summary strip (computed from the rows already fetched above).
$byStatus = array_fill_keys(ASSET_STATUSES, 0);
foreach ($rows as $r) { if (isset($byStatus[$r['status']])) $byStatus[$r['status']]++; }
$statusColor = ['Available' => '#146c36', 'In Use' => '#1d49b0', 'Under Repair' => '#86470a', 'Retired' => '#44566a'];
$statusBg    = ['Available' => '#e1f6e8', 'In Use' => '#e2ebff', 'Under Repair' => '#fdefd1', 'Retired' => '#e8edf2'];

ob_start();
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Asset Report</title>
<style>
  @page { margin: 28px 30px; }
  body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 9.5px; color: #0f1e2e; }
  .band { width: 100%; border-collapse: collapse; background: #0b2431; }
  .band td { border: 0; padding: 14px 16px; color: #ffffff; vertical-align: middle; }
  .band .logo { font-size: 18px; font-weight: bold; letter-spacing: .5px; }
  .band .logo span { color: #2dd4bf; }
  .band .sub { font-size: 9px; color: #9fb4c7; margin-top: 3px; }
  .band .right { text-align: right; font-size: 9px; color: #c9d7e4; }
  .rule { height: 3px; background: #0e9384; margin-bottom: 12px; }
  .meta { color: #5d6e7f; margin: 0 0 10px; }
  .sum { width: 100%; border-collapse: separate; border-spacing: 6px 0; margin: 0 0 12px; }
  .sum td { border: 0; padding: 8px 10px; border-radius: 4px; }
  .sum .n { font-size: 16px; font-weight: bold; }
  .sum .l { font-size: 8px; text-transform: uppercase; letter-spacing: .6px; }
  table.report { width: 100%; border-collapse: collapse; }
  table.report th, table.report td { border-bottom: 1px solid #dde5ec; padding: 5px 6px; text-align: left; vertical-align: top; }
  table.report th { background: #0b2431; color: #ffffff; font-size: 8.5px; text-transform: uppercase; letter-spacing: .5px; border-bottom: 0; }
  table.report tr.alt td { background: #f4f7fa; }
  .tag { font-family: DejaVu Sans Mono, monospace; font-weight: bold; }
  .pill { font-weight: bold; font-size: 8.5px; padding: 1px 6px; border-radius: 8px; }
  .num { text-align: right; }
  tfoot td { font-weight: bold; background: #e6f4f1; border-top: 2px solid #0e9384; border-bottom: 0; }
  .foot { margin-top: 10px; color: #8a9aab; font-size: 8px; text-align: center; }
  .noprint button { font: inherit; padding: 6px 14px; border: 0; border-radius: 6px; background: #0e9384; color: #fff; cursor: pointer; }
  @media print { .noprint { display: none; } }
</style></head>
<body>
<p class="noprint"><button onclick="window.print()">Print / Save as PDF</button></p>
<table class="band"><tr>
  <td><div class="logo">Asset<span>Track</span> - Asset Report</div><div class="sub">Asset management system</div></td>
  <td class="right">Generated <?= date('F j, Y g:i A') ?><br>by <?= e($_SESSION['full_name']) ?></td>
</tr></table>
<div class="rule"></div>
<div class="meta">
<?php if ($f['q'] || $f['status'] || $f['category'] || $f['location']): ?>Filtered view &middot; <?php endif; ?>
<?= count($rows) ?> record(s)</div>
<table class="sum"><tr>
  <?php foreach (ASSET_STATUSES as $st): ?>
  <td style="background: <?= $statusBg[$st] ?>; color: <?= $statusColor[$st] ?>;"><div class="n"><?= (int)$byStatus[$st] ?></div><div class="l"><?= e($st) ?></div></td>
  <?php endforeach; ?>
</tr></table>
<table class="report">
  <thead><tr><th>Tag</th><th>Name</th><th>Category</th><th>Location</th><th>Custodian</th><th>Purchased</th><th class="num">Cost (PHP)</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $i => $r): ?>
    <tr<?= $i % 2 ? ' class="alt"' : '' ?>>
      <td class="tag"><?= e($r['asset_tag']) ?></td><td><?= e($r['name']) ?></td><td><?= e($r['category']) ?></td>
      <td><?= e($r['location']) ?></td><td><?= e($r['custodian'] ?? '-') ?></td><td><?= e($r['purchase_date']) ?></td>
      <td class="num"><?= number_format((float)$r['purchase_cost'], 2) ?></td>
      <td><span class="pill" style="background: <?= $statusBg[$r['status']] ?? '#e8edf2' ?>; color: <?= $statusColor[$r['status']] ?? '#44566a' ?>;"><?= e($r['status']) ?></span></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
  <tfoot><tr><td colspan="6">Total value</td><td class="num"><?= number_format((float)$total, 2) ?></td><td></td></tr></tfoot>
</table>
<div class="foot">AssetTrack &middot; CC 106 Final Project</div>
</body></html>
<?php
$html = ob_get_clean();

$autoload = __DIR__ . '/../vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
    $dompdf = new Dompdf\Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();
    $dompdf->stream('assets_' . date('Ymd_His') . '.pdf', ['Attachment' => true]);
    exit;
}

echo $html;
