<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id     = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id === (int)$_SESSION['user_id']) {
        flash('error', 'You cannot change or delete your own account here.');
    } elseif ($action === 'role') {
        $role = ($_POST['role'] ?? '') === 'admin' ? 'admin' : 'user';
        $pdo->prepare('UPDATE users SET role = ? WHERE user_id = ?')->execute([$role, $id]);
        flash('success', 'Role updated.');
    } elseif ($action === 'delete') {
        try {
            $pdo->prepare('DELETE FROM users WHERE user_id = ?')->execute([$id]);
            flash('success', 'User deleted.');
        } catch (PDOException $e) {
            // Users who created assets or have audit history are kept so the records stay intact.
            flash('error', 'This user has asset or audit history and cannot be deleted. Change their role instead.');
        }
    }
    redirect('/admin/users.php');
}

$users = $pdo->query('SELECT user_id, full_name, username, email, role, created_at FROM users ORDER BY created_at')->fetchAll();

$pageTitle = 'Users';
require __DIR__ . '/../includes/header.php';
?>
<?php
$nAdmins = count(array_filter($users, fn($u) => $u['role'] === 'admin'));
$nUsers  = count($users) - $nAdmins;
?>
<div class="page-head">
  <div>
    <span class="eyebrow admin-eyebrow"><?= icon('shield-check') ?>Administration</span>
    <h1>Users</h1>
    <p class="sub">Manage who can sign in and what they can do.</p>
  </div>
</div>

<ul class="stats stats-3" aria-label="Accounts by role">
  <li class="stat tone-total"><span class="stat-in"><span class="stat-ico"><?= icon('users') ?></span><span class="stat-body"><strong data-count="<?= count($users) ?>"><?= count($users) ?></strong><span>Total accounts</span></span></span></li>
  <li class="stat tone-admin"><span class="stat-in"><span class="stat-ico"><?= icon('shield-check') ?></span><span class="stat-body"><strong data-count="<?= $nAdmins ?>"><?= $nAdmins ?></strong><span>Administrators</span></span></span></li>
  <li class="stat tone-in-use"><span class="stat-in"><span class="stat-ico"><?= icon('user') ?></span><span class="stat-body"><strong data-count="<?= $nUsers ?>"><?= $nUsers ?></strong><span>Standard users</span></span></span></li>
</ul>

<div class="table-wrap">
<table class="data">
  <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Joined</th><th><span class="sr-only">Actions</span></th></tr></thead>
  <tbody>
  <?php foreach ($users as $u): $self = (int)$u['user_id'] === (int)$_SESSION['user_id']; ?>
    <tr<?= $self ? ' class="is-self"' : '' ?>>
      <td><span class="person"><span class="avatar <?= $u['role'] === 'admin' ? 'is-admin' : '' ?>"><?= e(initials($u['full_name'])) ?></span><span class="cell-main"><?= e($u['full_name']) ?><?= $self ? ' <small class="you-pill">you</small>' : '' ?></span></span></td>
      <td><span class="mono"><?= e($u['username']) ?></span></td>
      <td><span class="mail"><?= e($u['email']) ?></span></td>
      <td>
        <?php if ($self): ?>
          <span class="role-pill role-<?= e($u['role']) ?>"><?= e($u['role']) ?></span>
        <?php else: ?>
        <form method="post" class="inline">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$u['user_id'] ?>">
          <input type="hidden" name="action" value="role">
          <select name="role" class="role-select role-<?= e($u['role']) ?>" aria-label="Role for <?= e($u['username']) ?>" onchange="this.form.submit()">
            <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>user</option>
            <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
          </select>
        </form>
        <?php endif; ?>
      </td>
      <td class="muted"><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
      <td class="row-actions">
        <?php if (!$self): ?>
        <form method="post" data-confirm="Delete user <?= e($u['username']) ?>?">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$u['user_id'] ?>">
          <input type="hidden" name="action" value="delete">
          <button type="submit" class="row-btn danger"><?= icon('trash') ?>Delete</button>
        </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
