<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

const LOG_PER_PAGE = 15;
$total = (int)$pdo->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn();
$pages = max(1, (int)ceil($total / LOG_PER_PAGE));
$page  = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
$offset = ($page - 1) * LOG_PER_PAGE;

$rows = $pdo->query(
    'SELECT l.created_at, l.action, l.details, u.username, a.asset_tag
     FROM audit_logs l
     JOIN users u ON u.user_id = l.user_id
     LEFT JOIN assets a ON a.asset_id = l.asset_id
     ORDER BY l.log_id DESC LIMIT ' . LOG_PER_PAGE . ' OFFSET ' . $offset
)->fetchAll();

$pageTitle = 'Audit log';
require __DIR__ . '/../includes/header.php';
?>
<?php
$actionIcon = ['CREATE' => 'file-plus', 'UPDATE' => 'pencil', 'DELETE' => 'trash', 'EXPORT' => 'download', 'LOGIN' => 'log-in'];
?>
<div class="page-head">
  <div>
    <span class="eyebrow admin-eyebrow"><?= icon('shield-check') ?>Administration</span>
    <h1>Audit log</h1>
    <p class="sub muted">Every login, change, and export is recorded here. <strong class="count-pill"><?= $total ?></strong> entries.</p>
  </div>
</div>
<div class="table-wrap">
<table class="data log">
  <thead><tr><th>When</th><th>User</th><th>Action</th><th>Asset</th><th>Details</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="when"><?= e(date('M j, Y g:i A', strtotime($r['created_at']))) ?></td>
      <td><span class="person"><span class="avatar avatar-sm"><?= e(initials($r['username'])) ?></span><span class="mono"><?= e($r['username']) ?></span></span></td>
      <td><span class="badge a-<?= strtolower($r['action']) ?>"><?= icon($actionIcon[$r['action']] ?? 'info') ?><?= e($r['action']) ?></span></td>
      <td><?php if ($r['asset_tag'] !== null): ?><span class="tag"><?= e($r['asset_tag']) ?></span><?php else: ?><span class="muted">-</span><?php endif; ?></td>
      <td><?= e($r['details']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php if ($pages > 1): ?>
<nav class="pager" aria-label="Pagination">
  <?php for ($i = 1; $i <= $pages; $i++): ?>
    <a href="?page=<?= $i ?>" <?= $i === $page ? 'aria-current="page" class="current"' : '' ?>><?= $i ?></a>
  <?php endfor; ?>
</nav>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
