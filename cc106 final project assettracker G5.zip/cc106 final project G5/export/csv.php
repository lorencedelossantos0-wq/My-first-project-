<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/asset_query.php';
require_login();

[$whereSql, $params] = asset_filters();
$stmt = $pdo->prepare(ASSET_SELECT . $whereSql . ' ORDER BY a.asset_tag');
$stmt->execute($params);

audit($pdo, 'EXPORT', null, 'Exported CSV report');

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="assets_' . date('Ymd_His') . '.csv"');

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel reads it correctly
fputcsv($out, ['Asset Tag', 'Name', 'Serial No', 'Category', 'Location', 'Supplier', 'Custodian', 'Department', 'Purchase Date', 'Cost (PHP)', 'Status']);
while ($r = $stmt->fetch()) {
    // Guard against CSV/Excel formula injection
    $safe = fn($v) => (is_string($v) && $v !== '' && strpbrk($v[0], "=+-@\t\r") !== false) ? "'" . $v : $v;
    fputcsv($out, array_map($safe, [
        $r['asset_tag'], $r['name'], $r['serial_no'], $r['category'], $r['location'], $r['supplier'],
        $r['custodian'], $r['department'], $r['purchase_date'], $r['purchase_cost'], $r['status'],
    ]));
}
fclose($out);
