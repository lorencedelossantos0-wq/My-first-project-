<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/asset_query.php';
require_login();

[$whereSql, $params, $f] = asset_filters();
$stmt = $pdo->prepare(ASSET_SELECT . $whereSql . ' ORDER BY a.asset_tag');
$stmt->execute($params);
$rows = $stmt->fetchAll();
audit($pdo, 'EXPORT', null, 'Exported PDF report');

$total = array_sum(array_column($rows, 'purchase_cost'));

ob_start();
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Asset Report</title>
<style>
  body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 10px; color: #1d2733; }
  h1 { font-size: 16px; margin: 0 0 2px; }
  .meta { color: #5b6672; margin-bottom: 10px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border: 1px solid #c9d0d8; padding: 4px 5px; text-align: left; vertical-align: top; }
  th { background: #e9eef3; }
  .num { text-align: right; }
  tfoot td { font-weight: bold; }
  @media print { .noprint { display: none; } }
</style></head>
<body>
<p class="noprint"><button onclick="window.print()">Print / Save as PDF</button></p>
<h1>AssetTrack - Asset Report</h1>
<div class="meta">Generated <?= date('F j, Y g:i A') ?> by <?= e($_SESSION['full_name']) ?>
<?php if ($f['q'] || $f['status'] || $f['category'] || $f['location']): ?> &middot; Filtered view<?php endif; ?>
&middot; <?= count($rows) ?> record(s)</div>
<table>
  <thead><tr><th>Tag</th><th>Name</th><th>Category</th><th>Location</th><th>Custodian</th><th>Purchased</th><th class="num">Cost (PHP)</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['asset_tag']) ?></td><td><?= e($r['name']) ?></td><td><?= e($r['category']) ?></td>
      <td><?= e($r['location']) ?></td><td><?= e($r['custodian'] ?? '-') ?></td><td><?= e($r['purchase_date']) ?></td>
      <td class="num"><?= number_format((float)$r['purchase_cost'], 2) ?></td><td><?= e($r['status']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
  <tfoot><tr><td colspan="6">Total value</td><td class="num"><?= number_format((float)$total, 2) ?></td><td></td></tr></tfoot>
</table>
</body></html>
<?php
$html = ob_get_clean();

$autoload = __DIR__ . '/../vendor/autoload.php';
if (is_file($autoload)) {
    require_once $autoload;
    $dompdf = new Dompdf\Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();
    $dompdf->stream('assets_' . date('Ymd_His') . '.pdf', ['Attachment' => true]);
    exit;
}

echo $html;
