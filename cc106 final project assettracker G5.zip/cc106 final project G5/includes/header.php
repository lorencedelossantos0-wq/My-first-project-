<?php
$pageTitle = $pageTitle ?? 'AssetTrack';
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | AssetTrack</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Serif:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= BASE_URL ?>/modules/dashboard.php">AssetTrack</a>
  <?php if (is_logged_in()): ?>
  <nav aria-label="Main">
    <a href="<?= BASE_URL ?>/modules/dashboard.php">Assets</a>
    <a href="<?= BASE_URL ?>/modules/create.php">Add asset</a>
    <?php if (is_admin()): ?>
      <a href="<?= BASE_URL ?>/admin/users.php">Users</a>
      <a href="<?= BASE_URL ?>/admin/audit_log.php">Audit log</a>
    <?php endif; ?>
  </nav>
  <div class="whoami">
    <span><?= e($_SESSION['full_name']) ?> <em class="role"><?= e($_SESSION['role']) ?></em></span>
    <a href="<?= BASE_URL ?>/logout.php">Log out</a>
  </div>
  <?php endif; ?>
</header>
<main class="page">
<?php show_flash(); ?>
