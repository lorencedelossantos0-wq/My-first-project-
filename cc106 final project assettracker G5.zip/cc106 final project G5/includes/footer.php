</main>
<footer class="foot">AssetTrack &middot; CC 106 Final Project</footer>
<script src="<?= BASE_URL ?>/assets/js/validation.js"></script>
</body>
</html>
