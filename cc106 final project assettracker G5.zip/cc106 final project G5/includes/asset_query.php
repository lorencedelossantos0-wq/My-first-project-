<?php

const ASSET_SELECT = '
    SELECT a.asset_id, a.asset_tag, a.name, a.serial_no, a.purchase_date, a.purchase_cost, a.status,
           c.name AS category, l.name AS location, s.name AS supplier,
           e.full_name AS custodian, d.name AS department, u.full_name AS created_by_name
    FROM assets a
    JOIN categories c        ON c.category_id = a.category_id
    JOIN locations  l        ON l.location_id = a.location_id
    JOIN users      u        ON u.user_id     = a.created_by
    LEFT JOIN suppliers s    ON s.supplier_id = a.supplier_id
    LEFT JOIN employees e    ON e.employee_id = a.custodian_id
    LEFT JOIN departments d  ON d.department_id = e.department_id';

const ASSET_COUNT = '
    SELECT COUNT(*)
    FROM assets a
    JOIN categories c        ON c.category_id = a.category_id
    JOIN locations  l        ON l.location_id = a.location_id
    LEFT JOIN employees e    ON e.employee_id = a.custodian_id';

function asset_filters(): array {
    $q        = trim($_GET['q'] ?? '');
    $category = (int)($_GET['category'] ?? 0);
    $location = (int)($_GET['location'] ?? 0);
    $status   = trim($_GET['status'] ?? '');

    $where = [];
    $params = [];

    if ($q !== '') {
        $where[] = '(a.asset_tag LIKE ? OR a.name LIKE ? OR a.serial_no LIKE ? OR e.full_name LIKE ?)';
        $like = '%' . $q . '%';
        array_push($params, $like, $like, $like, $like);
    }
    if ($category > 0) { $where[] = 'a.category_id = ?'; $params[] = $category; }
    if ($location > 0) { $where[] = 'a.location_id = ?'; $params[] = $location; }
    if (in_array($status, ASSET_STATUSES, true)) { $where[] = 'a.status = ?'; $params[] = $status; }

    return [
        $where ? ' WHERE ' . implode(' AND ', $where) : '',
        $params,
        ['q' => $q, 'category' => $category, 'location' => $location, 'status' => $status],
    ];
}
