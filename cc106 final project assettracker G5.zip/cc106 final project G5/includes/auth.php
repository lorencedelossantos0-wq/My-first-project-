<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// Base URL of the project folder, e.g. "/assettrack" (works in Laragon at http://assettrack.test too).
if (!defined('BASE_URL')) {
    $root = str_replace('\\', '/', realpath(__DIR__ . '/..'));
    $doc  = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
    define('BASE_URL', rtrim(str_replace($doc, '', $root), '/'));
}

require_once __DIR__ . '/functions.php';

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function require_login(): void {
    if (!is_logged_in()) {
        redirect('/login.php');
    }
}

function is_admin(): bool {
    return ($_SESSION['role'] ?? '') === 'admin';
}

function require_admin(): void {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        exit('403 - Admins only.');
    }
}
