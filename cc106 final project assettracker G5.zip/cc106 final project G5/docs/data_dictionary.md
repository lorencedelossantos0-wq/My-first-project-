# Data Dictionary

Database: `assettrack` (MySQL / InnoDB, utf8mb4)

## categories
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| category_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique category ID |
| name | VARCHAR(60) | UNIQUE | No | Category name (e.g. Laptop) |

## locations
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| location_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique location ID |
| name | VARCHAR(80) | UNIQUE | No | Room or area name |

## suppliers
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| supplier_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique supplier ID |
| name | VARCHAR(100) | UNIQUE | No | Supplier name |
| contact_email | VARCHAR(120) | | Yes | Contact email |
| phone | VARCHAR(30) | | Yes | Contact number |

## departments
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| department_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique department ID |
| name | VARCHAR(80) | UNIQUE | No | Department name |

## employees
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| employee_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique employee ID |
| full_name | VARCHAR(100) | | No | Employee name |
| email | VARCHAR(120) | UNIQUE | No | Employee email |
| department_id | INT UNSIGNED | FK -> departments | No | Department the employee belongs to |

## users
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| user_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique user ID |
| full_name | VARCHAR(100) | | No | Display name |
| username | VARCHAR(40) | UNIQUE | No | Login name |
| email | VARCHAR(120) | UNIQUE | No | Email address |
| password_hash | VARCHAR(255) | | No | bcrypt hash from `password_hash()` (never plain text) |
| role | ENUM('admin','user') | | No | Access level; default `user` |
| created_at | TIMESTAMP | | No | Account creation time |

## assets
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| asset_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique asset ID |
| asset_tag | VARCHAR(30) | UNIQUE | No | Inventory tag (e.g. AST-0001) |
| name | VARCHAR(120) | | No | Asset name / model |
| serial_no | VARCHAR(60) | | Yes | Manufacturer serial number |
| category_id | INT UNSIGNED | FK -> categories | No | Asset category |
| supplier_id | INT UNSIGNED | FK -> suppliers | Yes | Where it was bought |
| location_id | INT UNSIGNED | FK -> locations | No | Current location |
| custodian_id | INT UNSIGNED | FK -> employees | Yes | Employee responsible for the asset |
| purchase_date | DATE | | No | Date of purchase |
| purchase_cost | DECIMAL(12,2) | | No | Cost in PHP |
| status | ENUM('Available','In Use','Under Repair','Retired') | INDEX | No | Current condition |
| created_by | INT UNSIGNED | FK -> users | No | User who registered the asset |
| created_at | TIMESTAMP | | No | Record creation time |
| updated_at | TIMESTAMP | | No | Auto-updated on every change |

## audit_logs
| Column | Type | Key | Null | Description |
|---|---|---|---|---|
| log_id | INT UNSIGNED AUTO_INCREMENT | PK | No | Unique log ID |
| user_id | INT UNSIGNED | FK -> users | No | User who did the action |
| asset_id | INT UNSIGNED | FK -> assets | Yes | Asset affected (NULL for logins/exports or after deletion) |
| action | ENUM('CREATE','UPDATE','DELETE','EXPORT','LOGIN') | | No | Type of action |
| details | VARCHAR(255) | | Yes | Human-readable description |
| created_at | TIMESTAMP | | No | When it happened |
