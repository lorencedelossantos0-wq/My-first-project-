# Normalization Evidence (up to 3NF)

## Starting point: one flat table (unnormalized)

`asset_records(asset_tag, asset_name, serial_no, category, supplier_name, supplier_email, supplier_phone,
location, custodian_name, custodian_email, department, purchase_date, purchase_cost, status, created_by_name, ...)`

Problems: supplier, custodian, and department details repeat on every row, so a change (for example, a supplier's phone number)
must be edited in many places and rows can disagree with each other.

## 1NF: atomic values, no repeating groups
- Every column holds a single value (no comma-separated lists such as "Laptop, Desktop").
- Every table has a primary key (`asset_id`, `user_id`, ...).
- Audit history is stored as separate rows in `audit_logs` instead of a repeating "history" column on the asset.

## 2NF: no partial dependency on part of a key
- All tables use a single-column surrogate primary key, so no non-key column can depend on only part of a composite key.
- Each table is therefore in 2NF once it is in 1NF.

## 3NF: no transitive dependency (non-key column depending on another non-key column)

| Transitive dependency in the flat table | Fix |
|---|---|
| `supplier_name -> supplier_email, supplier_phone` | Moved to `suppliers`; `assets.supplier_id` references it |
| `custodian_name -> custodian_email, department` | Moved to `employees`; `assets.custodian_id` references it |
| `employee -> department` | Moved to `departments`; `employees.department_id` references it |
| `category` and `location` as repeated text | Moved to `categories` and `locations` lookup tables |
| `created_by_name` (depends on the user, not the asset) | Replaced with `assets.created_by` referencing `users` |

## Result: functional dependencies per table

- `categories`: category_id -> name
- `locations`: location_id -> name
- `suppliers`: supplier_id -> name, contact_email, phone
- `departments`: department_id -> name
- `employees`: employee_id -> full_name, email, department_id
- `users`: user_id -> full_name, username, email, password_hash, role, created_at
- `assets`: asset_id -> every other column (asset_tag is a candidate key)
- `audit_logs`: log_id -> user_id, asset_id, action, details, created_at

In every table, each non-key attribute depends on "the key, the whole key, and nothing but the key", so the schema is in **3NF**.

## Note on derived values
Nothing derived is stored. The total asset value and status counts are calculated with `SUM()` / `COUNT()` at query time.
