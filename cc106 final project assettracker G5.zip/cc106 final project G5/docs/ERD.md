# Entity Relationship Diagram

Paste the Mermaid block below into https://mermaid.live (or a Mermaid-enabled Markdown viewer) and export it as `ERD.png`
for your documentation.

```mermaid
erDiagram
    CATEGORIES  ||--o{ ASSETS      : "classifies (1:N)"
    LOCATIONS   ||--o{ ASSETS      : "houses (1:N)"
    SUPPLIERS   |o--o{ ASSETS      : "supplies (1:N)"
    EMPLOYEES   |o--o{ ASSETS      : "is custodian of (1:N)"
    DEPARTMENTS ||--o{ EMPLOYEES   : "employs (1:N)"
    USERS       ||--o{ ASSETS      : "registers (1:N)"
    USERS       ||--o{ AUDIT_LOGS  : "performs (1:N)"
    ASSETS      |o--o{ AUDIT_LOGS  : "is recorded in (1:N)"

    CATEGORIES  { int category_id PK  varchar name }
    LOCATIONS   { int location_id PK  varchar name }
    SUPPLIERS   { int supplier_id PK  varchar name  varchar contact_email  varchar phone }
    DEPARTMENTS { int department_id PK  varchar name }
    EMPLOYEES   { int employee_id PK  varchar full_name  varchar email  int department_id FK }
    USERS       { int user_id PK  varchar full_name  varchar username  varchar email  varchar password_hash  enum role  timestamp created_at }
    ASSETS      {
        int asset_id PK
        varchar asset_tag
        varchar name
        varchar serial_no
        int category_id FK
        int supplier_id FK
        int location_id FK
        int custodian_id FK
        date purchase_date
        decimal purchase_cost
        enum status
        int created_by FK
        timestamp created_at
        timestamp updated_at
    }
    AUDIT_LOGS  { int log_id PK  int user_id FK  int asset_id FK  enum action  varchar details  timestamp created_at }
```

## Relationship summary

| Parent | Child | Type | Notes |
|---|---|---|---|
| categories | assets | 1:N | Every asset has exactly one category |
| locations | assets | 1:N | Every asset is kept in exactly one location |
| suppliers | assets | 1:N | Optional; set to NULL if the supplier is removed |
| employees | assets | 1:N | Optional custodian; set to NULL if the employee is removed |
| departments | employees | 1:N | Every employee belongs to one department |
| users | assets | 1:N | Who registered the asset (`created_by`) |
| users | audit_logs | 1:N | Who performed the action |
| assets | audit_logs | 1:N | Optional; set to NULL when the asset is deleted so history is kept |
