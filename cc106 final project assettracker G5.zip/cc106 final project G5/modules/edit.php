<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM assets WHERE asset_id = ?');
$stmt->execute([$id]);
$asset = $stmt->fetch();
if (!$asset) {
    flash('error', 'That asset no longer exists.');
    redirect('/modules/dashboard.php');
}

$errors = [];
$data = [
    'asset_tag' => $asset['asset_tag'], 'name' => $asset['name'], 'serial_no' => (string)$asset['serial_no'],
    'category_id' => $asset['category_id'], 'supplier_id' => (int)$asset['supplier_id'],
    'location_id' => $asset['location_id'], 'custodian_id' => (int)$asset['custodian_id'],
    'purchase_date' => $asset['purchase_date'], 'purchase_cost' => $asset['purchase_cost'], 'status' => $asset['status'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    [$errors, $data] = validate_asset($pdo, $_POST, $id);

    if (!$errors) {
        $stmt = $pdo->prepare(
            'UPDATE assets SET asset_tag=?, name=?, serial_no=?, category_id=?, supplier_id=?, location_id=?,
                    custodian_id=?, purchase_date=?, purchase_cost=?, status=?
             WHERE asset_id=?'
        );
        $stmt->execute([
            $data['asset_tag'], $data['name'], $data['serial_no'] ?: null, $data['category_id'],
            $data['supplier_id'] ?: null, $data['location_id'], $data['custodian_id'] ?: null,
            $data['purchase_date'], $data['purchase_cost'], $data['status'], $id,
        ]);

        // Record what changed for the audit trail
        $changes = [];
        foreach (['asset_tag', 'name', 'status', 'location_id', 'custodian_id', 'purchase_cost'] as $k) {
            $before = (string)($asset[$k] ?? '');
            $after  = (string)$data[$k];
            if ($k === 'custodian_id' && $after === '0') $after = '';
            if ($k === 'purchase_cost') { $before = (string)(float)$before; $after = (string)(float)$after; }
            if ($before !== $after) $changes[] = $k;
        }
        audit($pdo, 'UPDATE', $id, 'Updated ' . $data['asset_tag'] . ($changes ? ' (changed: ' . implode(', ', $changes) . ')' : ''));
        flash('success', 'Asset ' . $data['asset_tag'] . ' updated.');
        redirect('/modules/dashboard.php');
    }
}

$pageTitle = 'Edit asset';
$submitLabel = 'Save changes';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1>Edit <?= e($asset['asset_tag']) ?></h1></div>
<?php require __DIR__ . '/_form.php'; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
