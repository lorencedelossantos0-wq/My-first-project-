<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login();

$errors = [];
$data = ['asset_tag' => '', 'name' => '', 'serial_no' => '', 'category_id' => 0, 'supplier_id' => 0,
         'location_id' => 0, 'custodian_id' => 0, 'purchase_date' => '', 'purchase_cost' => '', 'status' => 'Available'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    [$errors, $data] = validate_asset($pdo, $_POST);

    if (!$errors) {
        $stmt = $pdo->prepare(
            'INSERT INTO assets (asset_tag, name, serial_no, category_id, supplier_id, location_id, custodian_id,
                                 purchase_date, purchase_cost, status, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $data['asset_tag'], $data['name'], $data['serial_no'] ?: null, $data['category_id'],
            $data['supplier_id'] ?: null, $data['location_id'], $data['custodian_id'] ?: null,
            $data['purchase_date'], $data['purchase_cost'], $data['status'], $_SESSION['user_id'],
        ]);
        $id = (int)$pdo->lastInsertId();
        audit($pdo, 'CREATE', $id, 'Added asset ' . $data['asset_tag']);
        flash('success', 'Asset ' . $data['asset_tag'] . ' added.');
        redirect('/modules/dashboard.php');
    }
}

$pageTitle = 'Add asset';
$submitLabel = 'Save asset';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-head"><h1>Add asset</h1></div>
<?php require __DIR__ . '/_form.php'; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
