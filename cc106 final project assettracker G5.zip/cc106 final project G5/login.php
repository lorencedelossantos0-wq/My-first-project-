<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) redirect('/modules/dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT user_id, full_name, password_hash, role FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id']   = (int)$user['user_id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role']      = $user['role'];
        audit($pdo, 'LOGIN', null, 'User logged in');
        redirect('/modules/dashboard.php');
    }
    $error = 'Wrong username or password.'; 
}

$pageTitle = 'Log in';
require __DIR__ . '/includes/header.php';
?>
<section class="card narrow">
  <h1>Log in</h1>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" novalidate data-validate>
    <?= csrf_field() ?>
    <label>Username
      <input type="text" name="username" required autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>">
    </label>
    <label>Password
      <input type="password" name="password" required autocomplete="current-password">
    </label>
    <button class="btn primary" type="submit">Log in</button>
  </form>
  <p class="muted">No account? <a href="register.php">Create one</a></p>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
