<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';
redirect(is_logged_in() ? '/modules/dashboard.php' : '/login.php');
