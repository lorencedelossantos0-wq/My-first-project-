<?php

require_once 'config.php';

$bookDetails = $pdo->query(
    "SELECT
        b.book_id, b.title,
        a.full_name AS author,
        c.name AS category,
        b.published_year, b.language, b.price, b.stock
     FROM books b
     INNER JOIN authors a ON b.author_id = a.author_id
     INNER JOIN categories c ON b.category_id = c.category_id
     WHERE b.published_year >= 2015
     ORDER BY b.price DESC, b.book_id
     LIMIT 25"
)->fetchAll();

$categoryStats = $pdo->query(
    "SELECT
        c.name AS category,
        COUNT(b.book_id) AS total_books,
        ROUND(AVG(b.price), 2) AS average_price,
        SUM(b.stock) AS total_stock
     FROM categories c
     LEFT JOIN books b ON c.category_id = b.category_id
     GROUP BY c.category_id, c.name
     HAVING COUNT(b.book_id) > 0
     ORDER BY total_books DESC, c.name"
)->fetchAll();

$lowStock = $pdo->query(
    "SELECT COUNT(*) AS low_stock_count FROM books WHERE stock <= 2"
)->fetch();

$systemTotals = $pdo->query(
    "SELECT
        (SELECT COUNT(*) FROM books) AS books,
        (SELECT COUNT(*) FROM authors) AS authors,
        (SELECT COUNT(*) FROM categories) AS categories,
        (SELECT COALESCE(SUM(price * stock), 0) FROM books) AS inventory_value"
)->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Reports</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Library Reports</h1>
    <a class="report-link" href="index.php">Back to Management System</a>
</header>

<main>

    <section class="summary-grid">
        <div class="summary-box">
            <strong><?= e($systemTotals['books']) ?></strong>
            <span>Total Books</span>
        </div>

        <div class="summary-box">
            <strong><?= e($systemTotals['authors']) ?></strong>
            <span>Total Authors</span>
        </div>

        <div class="summary-box">
            <strong><?= e($systemTotals['categories']) ?></strong>
            <span>Total Categories</span>
        </div>

        <div class="summary-box">
            <strong><?= number_format($systemTotals['inventory_value'], 2) ?></strong>
            <span>Inventory Value</span>
        </div>

        <div class="summary-box warning">
            <strong><?= e($lowStock['low_stock_count']) ?></strong>
            <span>Low Stock Books (2 or fewer)</span>
        </div>
    </section>

    <section class="card">
        <h2>Category Aggregation Report</h2>

        <p>
            This report uses <code>COUNT()</code>, <code>AVG()</code>,
            <code>SUM()</code>, <code>GROUP BY</code>, and <code>HAVING</code>.
        </p>

        <table>
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Total Books</th>
                    <th>Average Price</th>
                    <th>Total Stock</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($categoryStats as $row): ?>
                    <tr>
                        <td><?= e($row['category']) ?></td>
                        <td><?= e($row['total_books']) ?></td>
                        <td><?= number_format($row['average_price'], 2) ?></td>
                        <td><?= e($row['total_stock']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>

    <section class="card">
        <h2>Advanced SQL Join Report</h2>

        <p>
            This report joins <code>books</code>, <code>authors</code>,
            and <code>categories</code> and filters with <code>WHERE</code>
            (books published in 2015 or later, highest price first).
        </p>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Book</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Year</th>
                    <th>Language</th>
                    <th>Price</th>
                    <th>Stock</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($bookDetails as $row): ?>
                    <tr>
                        <td><?= e($row['book_id']) ?></td>
                        <td><?= e($row['title']) ?></td>
                        <td><?= e($row['author']) ?></td>
                        <td><?= e($row['category']) ?></td>
                        <td><?= e($row['published_year']) ?></td>
                        <td><?= e($row['language']) ?></td>
                        <td><?= number_format($row['price'], 2) ?></td>
                        <td><?= e($row['stock']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>

</main>

</body>
</html>
