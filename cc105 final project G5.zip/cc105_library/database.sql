-- CC 105 Library Management System: database structure only.
-- Run this first, then run mock_data.sql to load the sample data.

DROP DATABASE IF EXISTS cc105_library;

CREATE DATABASE cc105_library
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE cc105_library;

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE authors (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) UNIQUE
);

-- Main sample dataset: 10 columns, 1,000 rows (loaded by mock_data.sql)
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    author_id INT NOT NULL,
    category_id INT NOT NULL,
    published_year YEAR NOT NULL,
    language VARCHAR(30) NOT NULL DEFAULT 'English',
    pages INT NOT NULL DEFAULT 100,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock INT NOT NULL DEFAULT 1,

    CONSTRAINT fk_books_authors
        FOREIGN KEY (author_id)
        REFERENCES authors(author_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_books_categories
        FOREIGN KEY (category_id)
        REFERENCES categories(category_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE INDEX idx_books_author ON books(author_id);
CREATE INDEX idx_books_category ON books(category_id);
