DROP DATABASE IF EXISTS cc105_library;

CREATE DATABASE cc105_library
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE cc105_library;

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE authors (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) UNIQUE
);

-- Main sample dataset: 10 columns, 1,000 rows
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    author_id INT NOT NULL,
    category_id INT NOT NULL,
    published_year YEAR NOT NULL,
    language VARCHAR(30) NOT NULL DEFAULT 'English',
    pages INT NOT NULL DEFAULT 100,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock INT NOT NULL DEFAULT 1,

    CONSTRAINT fk_books_authors
        FOREIGN KEY (author_id)
        REFERENCES authors(author_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_books_categories
        FOREIGN KEY (category_id)
        REFERENCES categories(category_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

CREATE INDEX idx_books_author ON books(author_id);
CREATE INDEX idx_books_category ON books(category_id);

INSERT INTO categories (name) VALUES
('Programming'),
('Database'),
('Web Development'),
('Networking'),
('Cybersecurity'),
('Artificial Intelligence'),
('Business'),
('Mathematics'),
('Science'),
('Reference');

DELIMITER $$

CREATE PROCEDURE seed_library_data()
BEGIN
    DECLARE i INT DEFAULT 1;

    WHILE i <= 50 DO
        INSERT INTO authors (full_name, email)
        VALUES (
            CONCAT('Author ', i),
            CONCAT('author', i, '@example.com')
        );

        SET i = i + 1;
    END WHILE;

    SET i = 1;

    WHILE i <= 1000 DO
        INSERT INTO books
        (
            isbn,
            title,
            author_id,
            category_id,
            published_year,
            language,
            pages,
            price,
            stock
        )
        VALUES
        (
            CONCAT('978000', LPAD(i, 7, '0')),
            CONCAT('Library Book Title ', i),
            MOD(i - 1, 50) + 1,
            MOD(i - 1, 10) + 1,
            2000 + MOD(i, 26),
            ELT(MOD(i, 4) + 1, 'English', 'Filipino', 'Spanish', 'Japanese'),
            80 + MOD(i * 7, 720),
            150 + MOD(i, 500),
            1 + MOD(i, 10)
        );

        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL seed_library_data();

DROP PROCEDURE seed_library_data;
