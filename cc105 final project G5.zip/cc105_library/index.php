<?php

require_once 'config.php';

$message = '';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        if ($action === 'save_book') {
            $bookId = (int)($_POST['book_id'] ?? 0);
            $isbn = trim($_POST['isbn'] ?? '');
            $title = trim($_POST['title'] ?? '');
            $authorId = (int)($_POST['author_id'] ?? 0);
            $categoryId = (int)($_POST['category_id'] ?? 0);
            $publishedYear = (int)($_POST['published_year'] ?? 0);
            $language = trim($_POST['language'] ?? 'English');
            $pages = (int)($_POST['pages'] ?? 0);
            $price = (float)($_POST['price'] ?? 0);
            $stock = (int)($_POST['stock'] ?? 0);

            if ($isbn === '' || $title === '' || $authorId <= 0 || $categoryId <= 0) {
                throw new Exception('Please complete all required book fields.');
            }

            if ($bookId > 0) {
                $stmt = $pdo->prepare(
                    "UPDATE books
                     SET isbn = ?, title = ?, author_id = ?,
                         category_id = ?, published_year = ?,
                         language = ?, pages = ?,
                         price = ?, stock = ?
                     WHERE book_id = ?"
                );
                $stmt->execute([
                    $isbn, $title, $authorId, $categoryId,
                    $publishedYear, $language, $pages,
                    $price, $stock, $bookId
                ]);
                $message = 'Book updated successfully.';
            } else {
                $stmt = $pdo->prepare(
                    "INSERT INTO books
                    (isbn, title, author_id, category_id,
                     published_year, language, pages, price, stock)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $stmt->execute([
                    $isbn, $title, $authorId, $categoryId,
                    $publishedYear, $language, $pages,
                    $price, $stock
                ]);
                $message = 'Book added successfully.';
            }
        }

        if ($action === 'delete_book') {
            $bookId = (int)($_POST['book_id'] ?? 0);
            $stmt = $pdo->prepare("DELETE FROM books WHERE book_id = ?");
            $stmt->execute([$bookId]);
            $message = 'Book deleted successfully.';
        }
    }
} catch (Throwable $error) {
    $message = 'Operation failed: ' . $error->getMessage();
}

$authors = $pdo->query("SELECT * FROM authors ORDER BY full_name")->fetchAll();
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$perPage = 25;
$totalBooks = (int)$pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
$totalPages = max(1, (int)ceil($totalBooks / $perPage));
$page = min(max(1, (int)($_GET['page'] ?? 1)), $totalPages);
$offset = ($page - 1) * $perPage;

$books = $pdo->query(
    "SELECT
        b.book_id, b.isbn, b.title, b.published_year, b.language,
        b.pages, b.price, b.stock,
        a.full_name AS author_name,
        c.name AS category_name
     FROM books b
     INNER JOIN authors a ON b.author_id = a.author_id
     INNER JOIN categories c ON b.category_id = c.category_id
     ORDER BY b.book_id
     LIMIT $perPage OFFSET $offset"
)->fetchAll();

$editBook = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM books WHERE book_id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editBook = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CC 105 Library Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Library Management System</h1>
    <p>CC 105 Final Project</p>
    <a class="report-link" href="reports.php">View Advanced Reports</a>
</header>

<main>

    <?php if ($message): ?>
        <div class="message"><?= e($message) ?></div>
    <?php endif; ?>

    <section class="card">
        <h2><?= $editBook ? 'Update Book' : 'Add Book' ?></h2>

        <form method="post">
            <input type="hidden" name="action" value="save_book">

            <input
                type="hidden"
                name="book_id"
                value="<?= e($editBook['book_id'] ?? 0) ?>"
            >

            <label>ISBN</label>
            <input
                type="text"
                name="isbn"
                required
                value="<?= e($editBook['isbn'] ?? '') ?>"
            >

            <label>Title</label>
            <input
                type="text"
                name="title"
                required
                value="<?= e($editBook['title'] ?? '') ?>"
            >

            <label>Author</label>
            <select name="author_id" required>
                <option value="">Select author</option>

                <?php foreach ($authors as $author): ?>
                    <option
                        value="<?= e($author['author_id']) ?>"
                        <?= isset($editBook['author_id']) &&
                            $editBook['author_id'] == $author['author_id']
                            ? 'selected'
                            : '' ?>
                    >
                        <?= e($author['full_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Category</label>
            <select name="category_id" required>
                <option value="">Select category</option>

                <?php foreach ($categories as $category): ?>
                    <option
                        value="<?= e($category['category_id']) ?>"
                        <?= isset($editBook['category_id']) &&
                            $editBook['category_id'] == $category['category_id']
                            ? 'selected'
                            : '' ?>
                    >
                        <?= e($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Published Year</label>
            <input
                type="number"
                name="published_year"
                min="1900"
                max="2100"
                value="<?= e($editBook['published_year'] ?? date('Y')) ?>"
            >

            <label>Language</label>
            <select name="language">
                <?php foreach (['English', 'Filipino', 'Spanish', 'Japanese'] as $lang): ?>
                    <option
                        value="<?= e($lang) ?>"
                        <?= ($editBook['language'] ?? 'English') === $lang ? 'selected' : '' ?>
                    >
                        <?= e($lang) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Pages</label>
            <input
                type="number"
                name="pages"
                min="1"
                value="<?= e($editBook['pages'] ?? 100) ?>"
            >

            <label>Price</label>
            <input
                type="number"
                name="price"
                min="0"
                step="0.01"
                value="<?= e($editBook['price'] ?? '0.00') ?>"
            >

            <label>Stock</label>
            <input
                type="number"
                name="stock"
                min="0"
                value="<?= e($editBook['stock'] ?? 1) ?>"
            >

            <button type="submit">
                <?= $editBook ? 'Update Book' : 'Add Book' ?>
            </button>

            <?php if ($editBook): ?>
                <a class="cancel" href="index.php?page=<?= e($page) ?>">Cancel Update</a>
            <?php endif; ?>
        </form>
    </section>

    <section class="card">
        <h2>Books (<?= e($totalBooks) ?> records)</h2>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ISBN</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Year</th>
                    <th>Language</th>
                    <th>Pages</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($books as $book): ?>
                    <tr>
                        <td><?= e($book['book_id']) ?></td>
                        <td><?= e($book['isbn']) ?></td>
                        <td><?= e($book['title']) ?></td>
                        <td><?= e($book['author_name']) ?></td>
                        <td><?= e($book['category_name']) ?></td>
                        <td><?= e($book['published_year']) ?></td>
                        <td><?= e($book['language']) ?></td>
                        <td><?= e($book['pages']) ?></td>
                        <td><?= number_format($book['price'], 2) ?></td>
                        <td><?= e($book['stock']) ?></td>
                        <td>
                            <a href="?page=<?= e($page) ?>&edit=<?= e($book['book_id']) ?>">
                                Edit
                            </a>

                            <form
                                method="post"
                                class="inline-form"
                                onsubmit="return confirm('Delete this book?')"
                            >
                                <input
                                    type="hidden"
                                    name="action"
                                    value="delete_book"
                                >

                                <input
                                    type="hidden"
                                    name="book_id"
                                    value="<?= e($book['book_id']) ?>"
                                >

                                <button class="danger" type="submit">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>

    <nav class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1 ?>">&laquo; Previous</a>
        <?php endif; ?>

        <span>Page <?= e($page) ?> of <?= e($totalPages) ?></span>

        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?>">Next &raquo;</a>
        <?php endif; ?>
    </nav>

</main>

</body>
</html>
