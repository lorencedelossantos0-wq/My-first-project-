<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: cart.php'); exit; }
verifyCsrf();

$shippingName    = trim($_POST['shipping_name'] ?? '');
$shippingPhone   = trim($_POST['shipping_phone'] ?? '');
$shippingAddress = trim($_POST['shipping_address'] ?? '');
$paymentMethod   = $_POST['payment_method'] ?? 'Cash on Delivery';

if ($shippingName === '' || $shippingPhone === '' || $shippingAddress === '') {
    setFlash('error', 'Please fill in all shipping details.');
    header('Location: checkout.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price
    FROM cart c JOIN products p ON p.id = c.product_id
    WHERE c.user_id = ?
");
$stmt->execute([currentUserId()]);
$items = $stmt->fetchAll();

if (empty($items)) {
    header('Location: cart.php');
    exit;
}

try {
    $pdo->beginTransaction();

    // Re-check stock for every line to avoid overselling.
    foreach ($items as $it) {
        $sizeStmt = $pdo->prepare("SELECT stock FROM product_sizes WHERE product_id = ? AND size = ? FOR UPDATE");
        $sizeStmt->execute([$it['product_id'], $it['size']]);
        $stock = $sizeStmt->fetchColumn();
        if ($stock === false || (int)$stock < $it['quantity']) {
            throw new Exception('"' . $it['name'] . '" (size ' . $it['size'] . ') no longer has enough stock.');
        }
    }

    $subtotal = 0;
    foreach ($items as $it) { $subtotal += $it['price'] * $it['quantity']; }
    $total = $subtotal + 120; // flat shipping fee

    $orderStmt = $pdo->prepare("
        INSERT INTO orders (user_id, total_amount, shipping_name, shipping_address, shipping_phone, payment_method, status)
        VALUES (?, ?, ?, ?, ?, ?, 'Pending')
    ");
    $orderStmt->execute([currentUserId(), $total, $shippingName, $shippingAddress, $shippingPhone, $paymentMethod]);
    $orderId = $pdo->lastInsertId();

    $itemStmt = $pdo->prepare("
        INSERT INTO order_items (order_id, product_id, product_name, size, quantity, price)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $decrementStmt = $pdo->prepare("UPDATE product_sizes SET stock = stock - ? WHERE product_id = ? AND size = ?");

    foreach ($items as $it) {
        $itemStmt->execute([$orderId, $it['product_id'], $it['name'], $it['size'], $it['quantity'], $it['price']]);
        $decrementStmt->execute([$it['quantity'], $it['product_id'], $it['size']]);
    }

    $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([currentUserId()]);

    $pdo->commit();

    setFlash('success', 'Order placed! Your order number is #' . $orderId . '.');
    header('Location: order_detail.php?id=' . $orderId);
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    setFlash('error', $e->getMessage());
    header('Location: cart.php');
    exit;
}
