<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

$pageTitle = 'Checkout';

$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price, p.image
    FROM cart c JOIN products p ON p.id = c.product_id
    WHERE c.user_id = ?
");
$stmt->execute([currentUserId()]);
$items = $stmt->fetchAll();

if (empty($items)) {
    setFlash('info', 'Your cart is empty.');
    header('Location: cart.php');
    exit;
}

$subtotal = 0;
foreach ($items as $it) { $subtotal += $it['price'] * $it['quantity']; }
$shipping = 120;
$total = $subtotal + $shipping;

$userStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->execute([currentUserId()]);
$user = $userStmt->fetch();

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / <a href="cart.php">Cart</a> / Checkout</div>

<section class="section" style="display:grid;grid-template-columns:1.3fr 1fr;gap:32px;align-items:start;">
    <div class="panel" style="margin:0;">
        <h3 style="margin-top:0;">Shipping details</h3>
        <form method="post" action="place_order.php">
            <?= csrfField() ?>
            <div class="field">
                <label for="shipping_name">Full name</label>
                <input type="text" id="shipping_name" name="shipping_name" value="<?= clean($user['full_name']) ?>" required>
            </div>
            <div class="field">
                <label for="shipping_phone">Phone number</label>
                <input type="tel" id="shipping_phone" name="shipping_phone" value="<?= clean($user['phone']) ?>" required>
            </div>
            <div class="field">
                <label for="shipping_address">Delivery address</label>
                <textarea id="shipping_address" name="shipping_address" required><?= clean($user['address']) ?></textarea>
            </div>
            <div class="field">
                <label for="payment_method">Payment method</label>
                <select id="payment_method" name="payment_method">
                    <option value="Cash on Delivery">Cash on Delivery</option>
                    <option value="GCash">GCash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                </select>
            </div>
            <button type="submit" class="btn btn-accent btn-block">Place order &mdash; <?= peso($total) ?></button>
        </form>
    </div>

    <div class="cart-summary" style="position:static;">
        <h3 style="margin-top:0;">Order summary</h3>
        <?php foreach ($items as $it): ?>
            <div class="summary-row">
                <span><?= clean($it['name']) ?> &times;<?= $it['quantity'] ?> <span class="review-count">(sz <?= clean($it['size']) ?>)</span></span>
                <span><?= peso($it['price'] * $it['quantity']) ?></span>
            </div>
        <?php endforeach; ?>
        <div class="summary-row"><span>Shipping</span><span><?= peso($shipping) ?></span></div>
        <div class="summary-row total"><span>Total</span><span><?= peso($total) ?></span></div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
