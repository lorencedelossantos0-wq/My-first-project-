<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: products.php'); exit; }
verifyCsrf();

$productId = (int)($_POST['product_id'] ?? 0);
$rating    = max(1, min(5, (int)($_POST['rating'] ?? 5)));
$comment   = trim($_POST['comment'] ?? '');

if ($comment === '') {
    setFlash('error', 'Please write a short comment with your rating.');
    header('Location: product_detail.php?id=' . $productId);
    exit;
}

$check = $pdo->prepare("SELECT id FROM reviews WHERE product_id = ? AND user_id = ?");
$check->execute([$productId, currentUserId()]);

if ($check->fetch()) {
    setFlash('info', 'You already reviewed this product.');
} else {
    $ins = $pdo->prepare("INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)");
    $ins->execute([$productId, currentUserId(), $rating, $comment]);
    setFlash('success', 'Thanks for your review!');
}

header('Location: product_detail.php?id=' . $productId . '#featured');
exit;
