<?php
/**
 * Database connection (PDO / MySQL)
 * Default values match a stock Laragon install (user: root, no password).
 * Edit these four lines if your setup is different.
 */
$DB_HOST = 'localhost';
$DB_NAME = 'shoeshop';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage() .
        '<br>Make sure Laragon (MySQL + Apache) is running and that you imported database.sql.');
}
