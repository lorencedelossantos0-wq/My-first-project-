<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: products.php'); exit; }
verifyCsrf();

if (!isLoggedIn()) {
    setFlash('info', 'Please log in first to add items to your cart.');
    header('Location: login.php?next=' . urlencode('product_detail.php?id=' . (int)($_POST['product_id'] ?? 0)));
    exit;
}

$productId = (int)($_POST['product_id'] ?? 0);
$size      = trim($_POST['size'] ?? '');
$quantity  = max(1, (int)($_POST['quantity'] ?? 1));

$sizeStmt = $pdo->prepare("SELECT * FROM product_sizes WHERE product_id = ? AND size = ?");
$sizeStmt->execute([$productId, $size]);
$sizeRow = $sizeStmt->fetch();

if (!$sizeRow || $sizeRow['stock'] < 1) {
    setFlash('error', 'That size is currently out of stock.');
    header('Location: product_detail.php?id=' . $productId);
    exit;
}

// Already in cart? bump quantity instead of duplicating the row.
$existing = $pdo->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ? AND size = ?");
$existing->execute([currentUserId(), $productId, $size]);
$row = $existing->fetch();

$desiredQty = $quantity + ($row ? $row['quantity'] : 0);
$desiredQty = min($desiredQty, $sizeRow['stock']);

if ($row) {
    $upd = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
    $upd->execute([$desiredQty, $row['id']]);
} else {
    $ins = $pdo->prepare("INSERT INTO cart (user_id, product_id, size, quantity) VALUES (?, ?, ?, ?)");
    $ins->execute([currentUserId(), $productId, $size, $desiredQty]);
}

setFlash('success', 'Added to your cart.');
header('Location: cart.php');
exit;
