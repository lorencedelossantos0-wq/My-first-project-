<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

$productId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT p.*, c.name AS category_name
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.id = ? AND p.is_active = 1
");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit;
}

$pageTitle = $product['name'];

$sizeStmt = $pdo->prepare("SELECT * FROM product_sizes WHERE product_id = ? ORDER BY (size + 0) ASC");
$sizeStmt->execute([$productId]);
$sizes = $sizeStmt->fetchAll();

$reviewStmt = $pdo->prepare("
    SELECT r.*, u.full_name
    FROM reviews r
    JOIN users u ON u.id = r.user_id
    WHERE r.product_id = ?
    ORDER BY r.created_at DESC
");
$reviewStmt->execute([$productId]);
$reviews = $reviewStmt->fetchAll();

$avgRating = 0;
if (count($reviews) > 0) {
    $avgRating = array_sum(array_column($reviews, 'rating')) / count($reviews);
}

$userAlreadyReviewed = false;
if (isLoggedIn()) {
    foreach ($reviews as $r) {
        if ($r['user_id'] == currentUserId()) { $userAlreadyReviewed = true; break; }
    }
}

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / <a href="products.php">Shop</a> / <?= clean($product['name']) ?></div>

<section class="section" style="display:grid;grid-template-columns:1fr 1fr;gap:44px;">
    <div class="product-thumb" style="aspect-ratio:1/1;border-radius:var(--radius);border:1px solid var(--line);">
        <img src="<?= productImageUrl($product['image']) ?>" alt="<?= clean($product['name']) ?>">
    </div>

    <div>
        <div class="eyebrow"><?= clean($product['brand'] ?: 'STRIDE') ?> &middot; <?= clean($product['category_name'] ?? 'Uncategorized') ?></div>
        <h1 style="font-size:2rem;"><?= clean($product['name']) ?></h1>
        <div style="margin-bottom:10px;">
            <?= starRating($avgRating) ?>
            <span class="review-count"><?= number_format($avgRating, 1) ?> (<?= count($reviews) ?> review<?= count($reviews) === 1 ? '' : 's' ?>)</span>
        </div>
        <span class="shoebox-tag lg accent"><?= peso($product['price']) ?></span>
        <p style="margin-top:18px;"><?= nl2br(clean($product['description'])) ?></p>

        <?php if (empty($sizes)): ?>
            <div class="alert alert-info">No sizes configured for this product yet.</div>
        <?php else: ?>
        <form action="cart_add.php" method="post">
            <?= csrfField() ?>
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            <div class="field">
                <label>Select size (PH)</label>
                <div class="pill-select" id="sizeSelect">
                    <?php foreach ($sizes as $s): $out = $s['stock'] <= 0; ?>
                        <label class="<?= $out ? 'disabled' : '' ?>">
                            <input type="radio" name="size" value="<?= clean($s['size']) ?>" <?= $out ? 'disabled' : '' ?> required>
                            <span><?= clean($s['size']) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="field" style="max-width:140px;">
                <label>Quantity</label>
                <input type="number" name="quantity" value="1" min="1" max="10">
            </div>
            <button type="submit" class="btn btn-accent">Add to cart</button>
        </form>
        <?php endif; ?>
    </div>
</section>

<section class="section" style="border-top:1px solid var(--line);">
    <h2>Reviews</h2>

    <?php if (isLoggedIn() && !$userAlreadyReviewed): ?>
    <div class="form-card wide" style="margin:0 0 30px;">
        <h3 style="margin-top:0;">Write a review</h3>
        <form action="add_review.php" method="post">
            <?= csrfField() ?>
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            <div class="field">
                <label>Your rating</label>
                <div id="ratingInput" style="font-size:1.6rem;cursor:pointer;color:var(--accent-dark);">
                    <?php for ($i = 1; $i <= 5; $i++): ?><span class="star-choice" data-value="<?= $i ?>">&#9734;</span><?php endfor; ?>
                </div>
                <input type="hidden" name="rating" id="ratingValue" value="5">
            </div>
            <div class="field">
                <label>Comment</label>
                <textarea name="comment" placeholder="How did the fit and quality feel?" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit review</button>
        </form>
    </div>
    <?php elseif (!isLoggedIn()): ?>
        <div class="alert alert-info"><a href="login.php">Log in</a> to leave a review.</div>
    <?php else: ?>
        <div class="alert alert-info">You've already reviewed this product &mdash; thanks!</div>
    <?php endif; ?>

    <?php if (empty($reviews)): ?>
        <p style="color:var(--muted);">No reviews yet. Be the first to share your fit.</p>
    <?php else: ?>
        <?php foreach ($reviews as $r): ?>
            <div class="review">
                <div class="review-head">
                    <span class="review-author"><?= clean($r['full_name']) ?></span>
                    <span class="review-date"><?= timeAgo($r['created_at']) ?></span>
                </div>
                <?= starRating($r['rating']) ?>
                <p style="margin-top:6px;"><?= nl2br(clean($r['comment'])) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>

<style>
@media (max-width: 800px) {
    section.section[style*="grid-template-columns:1fr 1fr"] { grid-template-columns: 1fr !important; }
}
</style>
