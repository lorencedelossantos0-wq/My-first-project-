// ---------- Mobile nav toggle ----------
document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.getElementById('navToggle');
    var links = document.getElementById('navLinks');
    if (toggle && links) {
        toggle.addEventListener('click', function () {
            links.classList.toggle('open');
        });
    }

    // ---------- Confirm before destructive actions ----------
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(el.getAttribute('data-confirm'))) {
                e.preventDefault();
            }
        });
    });

    // ---------- Quantity steppers (cart page) ----------
    document.querySelectorAll('.qty-stepper').forEach(function (stepper) {
        var input = stepper.querySelector('.qty-input');
        var min = parseInt(input.min || '1', 10);
        var max = parseInt(input.max || '99', 10);
        stepper.querySelectorAll('[data-step]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var val = parseInt(input.value, 10) || min;
                val += parseInt(btn.getAttribute('data-step'), 10);
                if (val < min) val = min;
                if (val > max) val = max;
                input.value = val;
                stepper.closest('form').submit();
            });
        });
    });

    // ---------- Star rating input (review form) ----------
    var starInput = document.getElementById('ratingInput');
    if (starInput) {
        var stars = starInput.querySelectorAll('.star-choice');
        var hidden = document.getElementById('ratingValue');
        stars.forEach(function (star) {
            star.addEventListener('click', function () {
                var val = star.getAttribute('data-value');
                hidden.value = val;
                stars.forEach(function (s) {
                    s.textContent = s.getAttribute('data-value') <= val ? '\u2605' : '\u2606';
                });
            });
        });
    }

    // ---------- Size pill selection sync (product detail) ----------
    document.querySelectorAll('.pill-select input[type=radio]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            document.querySelectorAll('.pill-select label').forEach(function (l) {
                l.style.background = '';
            });
        });
    });
});
