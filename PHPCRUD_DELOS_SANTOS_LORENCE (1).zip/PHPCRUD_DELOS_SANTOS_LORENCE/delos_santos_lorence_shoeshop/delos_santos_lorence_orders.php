<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

$pageTitle = 'My Orders';

$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->execute([currentUserId()]);
$orders = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / My Orders</div>

<section class="section">
    <h2>My orders</h2>

    <?php if (empty($orders)): ?>
        <div class="empty-state">
            <div class="icon">&#128230;</div>
            <p>You haven't placed any orders yet.</p>
            <a href="products.php" class="btn btn-primary">Start shopping</a>
        </div>
    <?php else: ?>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Order #</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $o):
                $countStmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) FROM order_items WHERE order_id = ?");
                $countStmt->execute([$o['id']]);
                $itemCount = $countStmt->fetchColumn();
                $badgeClass = 'badge-' . strtolower($o['status']);
            ?>
                <tr>
                    <td><strong>#<?= $o['id'] ?></strong></td>
                    <td><?= date('M j, Y', strtotime($o['order_date'])) ?></td>
                    <td><?= $itemCount ?> item<?= $itemCount == 1 ? '' : 's' ?></td>
                    <td><?= peso($o['total_amount']) ?></td>
                    <td><span class="badge <?= $badgeClass ?>"><?= clean($o['status']) ?></span></td>
                    <td><a href="order_detail.php?id=<?= $o['id'] ?>" class="btn btn-ghost btn-sm">View</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
