<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Home';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$featured = $pdo->query("
    SELECT p.*, c.name AS category_name,
           COALESCE(AVG(r.rating), 0) AS avg_rating,
           COUNT(DISTINCT r.id) AS review_count
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN reviews r ON r.product_id = p.id
    WHERE p.is_active = 1
    GROUP BY p.id
    ORDER BY p.created_at DESC
    LIMIT 8
")->fetchAll();

include 'includes/header.php';
?>

<section class="hero">
    <div class="container">
        <div>
            <div class="eyebrow">New drops every week</div>
            <h1>Find your <em>next</em> pair.</h1>
            <p class="lead">Running, basketball, training, or just walking around &mdash; STRIDE stocks shoes for every kind of day, sized and ready to ship.</p>
            <div class="hero-actions">
                <a href="products.php" class="btn btn-accent">Shop all shoes</a>
                <a href="#featured" class="btn btn-outline" style="border-color:#fff;color:#fff;">See what's new</a>
            </div>
        </div>
        <div class="hero-panel">
            <div class="stat"><span>Categories</span><span><?= count($categories) ?> curated</span></div>
            <div class="stat"><span>Sizes stocked</span><span>PH 6 &ndash; 11</span></div>
            <div class="stat"><span>Payment</span><span>COD available</span></div>
            <div class="stat"><span>Returns</span><span>7-day exchange</span></div>
            <div class="hero-tag">#WalkTheStride</div>
        </div>
    </div>
</section>

<div class="container">
    <section class="section" id="featured">
        <div class="section-head">
            <div>
                <div class="eyebrow">Shop by category</div>
                <h2>Browse the wall</h2>
            </div>
        </div>
        <div class="chip-row">
            <a href="products.php" class="chip active">All</a>
            <?php foreach ($categories as $cat): ?>
                <a href="products.php?category=<?= $cat['id'] ?>" class="chip"><?= clean($cat['name']) ?></a>
            <?php endforeach; ?>
        </div>

        <div class="section-head">
            <div>
                <div class="eyebrow">Just landed</div>
                <h2>Featured pairs</h2>
            </div>
            <a href="products.php" class="btn btn-ghost btn-sm">View all &rarr;</a>
        </div>

        <?php if (empty($featured)): ?>
            <div class="empty-state">
                <div class="icon">&#128092;</div>
                <p>No products yet &mdash; check back soon.</p>
            </div>
        <?php else: ?>
        <div class="product-grid">
            <?php foreach ($featured as $p): ?>
                <div class="product-card">
                    <a href="product_detail.php?id=<?= $p['id'] ?>" class="product-thumb">
                        <img src="<?= productImageUrl($p['image']) ?>" alt="<?= clean($p['name']) ?>">
                    </a>
                    <div class="product-body">
                        <div class="product-brand"><?= clean($p['brand'] ?: $p['category_name']) ?></div>
                        <h3 class="product-name"><a href="product_detail.php?id=<?= $p['id'] ?>"><?= clean($p['name']) ?></a></h3>
                        <div>
                            <?= starRating($p['avg_rating']) ?>
                            <span class="review-count">(<?= $p['review_count'] ?>)</span>
                        </div>
                        <span class="shoebox-tag accent"><?= peso($p['price']) ?></span>
                        <a href="product_detail.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm" style="margin-top:10px;">View pair</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
