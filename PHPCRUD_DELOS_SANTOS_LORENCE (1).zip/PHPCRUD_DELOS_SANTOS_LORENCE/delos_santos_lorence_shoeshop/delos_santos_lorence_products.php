<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

$pageTitle = 'Shop';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search     = trim($_GET['search'] ?? '');
$sort       = $_GET['sort'] ?? 'newest';

$where  = ['p.is_active = 1'];
$params = [];

if ($categoryId > 0) {
    $where[] = 'p.category_id = ?';
    $params[] = $categoryId;
}
if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.brand LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$orderBy = 'p.created_at DESC';
if ($sort === 'price_asc')  $orderBy = 'p.price ASC';
if ($sort === 'price_desc') $orderBy = 'p.price DESC';
if ($sort === 'name')       $orderBy = 'p.name ASC';
if ($sort === 'rating')     $orderBy = 'avg_rating DESC';

$sql = "
    SELECT p.*, c.name AS category_name,
           COALESCE(AVG(r.rating), 0) AS avg_rating,
           COUNT(DISTINCT r.id) AS review_count,
           COALESCE(SUM(ps.stock), 0) AS total_stock
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN reviews r ON r.product_id = p.id
    LEFT JOIN product_sizes ps ON ps.product_id = p.id
    WHERE " . implode(' AND ', $where) . "
    GROUP BY p.id
    ORDER BY $orderBy
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / Shop</div>

<section class="section">
    <div class="section-head">
        <div>
            <div class="eyebrow"><?= count($products) ?> pairs available</div>
            <h2>Shop all shoes</h2>
        </div>
        <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;">
            <input type="search" name="search" placeholder="Search name or brand&hellip;" value="<?= clean($search) ?>" style="min-width:200px;">
            <?php if ($categoryId): ?><input type="hidden" name="category" value="<?= $categoryId ?>"><?php endif; ?>
            <select name="sort" onchange="this.form.submit()">
                <option value="newest"    <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
                <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
                <option value="price_desc"<?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                <option value="rating"    <?= $sort === 'rating' ? 'selected' : '' ?>>Top Rated</option>
                <option value="name"      <?= $sort === 'name' ? 'selected' : '' ?>>Name A&ndash;Z</option>
            </select>
            <button class="btn btn-outline btn-sm" type="submit">Search</button>
        </form>
    </div>

    <div class="chip-row">
        <a href="products.php<?= $search ? '?search=' . urlencode($search) : '' ?>" class="chip <?= !$categoryId ? 'active' : '' ?>">All</a>
        <?php foreach ($categories as $cat):
            $qs = http_build_query(array_filter(['category' => $cat['id'], 'search' => $search, 'sort' => $sort]));
        ?>
            <a href="products.php?<?= $qs ?>" class="chip <?= $categoryId == $cat['id'] ? 'active' : '' ?>"><?= clean($cat['name']) ?></a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($products)): ?>
        <div class="empty-state">
            <div class="icon">&#128269;</div>
            <p>No shoes match your search. Try a different keyword or category.</p>
        </div>
    <?php else: ?>
    <div class="product-grid">
        <?php foreach ($products as $p): ?>
            <div class="product-card">
                <a href="product_detail.php?id=<?= $p['id'] ?>" class="product-thumb">
                    <img src="<?= productImageUrl($p['image']) ?>" alt="<?= clean($p['name']) ?>">
                </a>
                <div class="product-body">
                    <div class="product-brand"><?= clean($p['brand'] ?: $p['category_name']) ?></div>
                    <h3 class="product-name"><a href="product_detail.php?id=<?= $p['id'] ?>"><?= clean($p['name']) ?></a></h3>
                    <div>
                        <?= starRating($p['avg_rating']) ?>
                        <span class="review-count">(<?= $p['review_count'] ?>)</span>
                    </div>
                    <span class="shoebox-tag accent"><?= peso($p['price']) ?></span>
                    <?php if ($p['total_stock'] <= 0): ?>
                        <span class="badge badge-outstock" style="margin-top:6px;width:fit-content;">Out of stock</span>
                    <?php elseif ($p['total_stock'] <= 5): ?>
                        <span class="badge badge-lowstock" style="margin-top:6px;width:fit-content;">Low stock</span>
                    <?php endif; ?>
                    <a href="product_detail.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm" style="margin-top:10px;">View pair</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
