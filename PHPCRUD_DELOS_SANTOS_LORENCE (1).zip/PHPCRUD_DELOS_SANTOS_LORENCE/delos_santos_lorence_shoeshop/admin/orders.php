<?php
require_once __DIR__ . '/includes/admin_auth.php';
$pageTitle = 'Orders';

$statusFilter = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');
$statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

$where = '1=1';
$params = [];
if ($statusFilter && in_array($statusFilter, $statuses, true)) {
    $where = 'o.status = ?';
    $params[] = $statusFilter;
}
if ($search !== '') {
    $where .= ' AND (o.id = ? OR u.full_name LIKE ? OR u.email LIKE ?)';
    $params[] = ctype_digit($search) ? (int)$search : 0;
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$stmt = $pdo->prepare("
    SELECT o.*, u.full_name, u.email
    FROM orders o JOIN users u ON u.id = o.user_id
    WHERE $where
    ORDER BY o.order_date DESC
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

$summary = $pdo->query("SELECT status, COUNT(*) AS total FROM orders GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);

include __DIR__ . '/includes/admin_header.php';
?>

<div class="toolbar">
    <form method="get">
        <?php if ($statusFilter): ?><input type="hidden" name="status" value="<?= clean($statusFilter) ?>"><?php endif; ?>
        <input type="search" name="search" placeholder="Search order # or customer..." value="<?= clean($search) ?>">
        <button class="btn btn-outline btn-sm" type="submit">Search</button>
    </form>
    <div class="chip-row" style="margin:0;">
        <a href="orders.php<?= $search !== '' ? '?search=' . urlencode($search) : '' ?>" class="chip <?= !$statusFilter ? 'active' : '' ?>">All (<?= array_sum($summary) ?>)</a>
        <?php foreach ($statuses as $s): ?>
            <a href="orders.php?status=<?= urlencode($s) ?><?= $search !== '' ? '&search=' . urlencode($search) : '' ?>" class="chip <?= $statusFilter === $s ? 'active' : '' ?>"><?= $s ?> (<?= (int)($summary[$s] ?? 0) ?>)</a>
        <?php endforeach; ?>
    </div>
</div>

<div class="table-wrap">
    <table>
        <thead><tr><th>Order #</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($orders as $o): ?>
            <tr>
                <td>#<?= $o['id'] ?></td>
                <td><?= clean($o['full_name']) ?><br><span class="review-count"><?= clean($o['email']) ?></span></td>
                <td><?= date('M j, Y g:i A', strtotime($o['order_date'])) ?></td>
                <td><?= peso($o['total_amount']) ?></td>
                <td><span class="badge badge-<?= strtolower($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                <td><a href="order_view.php?id=<?= $o['id'] ?>" class="btn btn-ghost btn-sm">View</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($orders)): ?>
            <tr><td colspan="6" style="text-align:center;color:var(--muted);">No orders found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
