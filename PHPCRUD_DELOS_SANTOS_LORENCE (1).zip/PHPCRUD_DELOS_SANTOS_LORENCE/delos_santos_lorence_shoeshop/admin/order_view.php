<?php
require_once __DIR__ . '/includes/admin_auth.php';

$orderId = (int)($_GET['id'] ?? $_POST['order_id'] ?? 0);
$statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $newStatus = $_POST['status'] ?? '';

    if (in_array($newStatus, $statuses, true)) {
        $current = $pdo->prepare("SELECT status FROM orders WHERE id = ?");
        $current->execute([$orderId]);
        $oldStatus = $current->fetchColumn();

        $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$newStatus, $orderId]);

        // Restock items if the order is being cancelled for the first time.
        if ($newStatus === 'Cancelled' && $oldStatus !== 'Cancelled') {
            $items = $pdo->prepare("SELECT product_id, size, quantity FROM order_items WHERE order_id = ?");
            $items->execute([$orderId]);
            $restock = $pdo->prepare("UPDATE product_sizes SET stock = stock + ? WHERE product_id = ? AND size = ?");
            foreach ($items->fetchAll() as $it) {
                $restock->execute([$it['quantity'], $it['product_id'], $it['size']]);
            }
        }

        setFlash('success', 'Order status updated to ' . $newStatus . '.');
    }
    header('Location: order_view.php?id=' . $orderId);
    exit;
}

$stmt = $pdo->prepare("SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) { header('Location: orders.php'); exit; }

$pageTitle = 'Order #' . $order['id'];

$itemsStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();

include __DIR__ . '/includes/admin_header.php';
?>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:24px;align-items:start;">
    <div class="admin-panel" style="margin:0;">
        <h3 style="margin-top:0;">Items</h3>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Product</th><th>Size</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr></thead>
                <tbody>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td><?= clean($it['product_name']) ?></td>
                        <td><?= clean($it['size']) ?></td>
                        <td><?= $it['quantity'] ?></td>
                        <td><?= peso($it['price']) ?></td>
                        <td><?= peso($it['price'] * $it['quantity']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div>
        <div class="admin-panel">
            <h3 style="margin-top:0;">Customer</h3>
            <p style="margin-bottom:4px;"><strong><?= clean($order['full_name']) ?></strong></p>
            <p style="margin-bottom:4px;color:var(--muted);"><?= clean($order['email']) ?></p>
            <hr style="border:none;border-top:1px solid var(--line);margin:12px 0;">
            <p style="margin-bottom:4px;"><?= clean($order['shipping_name']) ?></p>
            <p style="margin-bottom:4px;color:var(--ink-soft);"><?= nl2br(clean($order['shipping_address'])) ?></p>
            <p style="margin-bottom:0;color:var(--ink-soft);"><?= clean($order['shipping_phone']) ?></p>
        </div>

        <div class="admin-panel">
            <h3 style="margin-top:0;">Order status</h3>
            <p class="review-count">Current: <span class="badge badge-<?= strtolower($order['status']) ?>"><?= clean($order['status']) ?></span></p>
            <form method="post" class="status-form">
                <?= csrfField() ?>
                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                <select name="status">
                    <?php foreach ($statuses as $s): ?>
                        <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary btn-sm">Update</button>
            </form>
            <p class="hint" style="margin-top:10px;">Payment: <?= clean($order['payment_method']) ?><br>Total: <strong><?= peso($order['total_amount']) ?></strong></p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
