<?php
require_once __DIR__ . '/includes/admin_auth.php';

$sizeOptions = ['6','6.5','7','7.5','8','8.5','9','9.5','10','10.5','11'];
$productId = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$isEdit = $productId > 0;
$pageTitle = $isEdit ? 'Edit Menu Item' : 'Add Menu Item';
$errors = [];

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$product = ['name' => '', 'brand' => '', 'category_id' => '', 'description' => '', 'price' => '', 'image' => 'no-image.svg', 'is_active' => 1];
$stockBySize = array_fill_keys($sizeOptions, '');

if ($isEdit) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $found = $stmt->fetch();
    if (!$found) { header('Location: products.php'); exit; }
    $product = $found;

    $sizeStmt = $pdo->prepare("SELECT size, stock FROM product_sizes WHERE product_id = ?");
    $sizeStmt->execute([$productId]);
    foreach ($sizeStmt->fetchAll() as $row) { $stockBySize[$row['size']] = $row['stock']; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $product['name']        = trim($_POST['name'] ?? '');
    $product['brand']       = trim($_POST['brand'] ?? '');
    $product['category_id'] = $_POST['category_id'] ?: null;
    $product['description'] = trim($_POST['description'] ?? '');
    $product['price']       = $_POST['price'] ?? '';
    $product['is_active']   = isset($_POST['is_active']) ? 1 : 0;
    $postedSizes             = $_POST['stock'] ?? [];

    if ($product['name'] === '') $errors[] = 'Product name is required.';
    if (!is_numeric($product['price']) || $product['price'] < 0) $errors[] = 'Enter a valid price.';

    [$uploadOk, $imageResult] = handleProductImageUpload('image', __DIR__ . '/../uploads/products', $product['image']);
    if (!$uploadOk) { $errors[] = $imageResult; }

    if (empty($errors)) {
        $product['image'] = $imageResult;

        if ($isEdit) {
            $pdo->prepare("UPDATE products SET category_id=?, name=?, brand=?, description=?, price=?, image=?, is_active=? WHERE id=?")
                ->execute([$product['category_id'], $product['name'], $product['brand'], $product['description'], $product['price'], $product['image'], $product['is_active'], $productId]);
        } else {
            $pdo->prepare("INSERT INTO products (category_id, name, brand, description, price, image, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)")
                ->execute([$product['category_id'], $product['name'], $product['brand'], $product['description'], $product['price'], $product['image'], $product['is_active']]);
            $productId = $pdo->lastInsertId();
        }

        // Replace size/stock rows for simplicity.
        $pdo->prepare("DELETE FROM product_sizes WHERE product_id = ?")->execute([$productId]);
        $insSize = $pdo->prepare("INSERT INTO product_sizes (product_id, size, stock) VALUES (?, ?, ?)");
        foreach ($sizeOptions as $sz) {
            $stock = (int)($postedSizes[$sz] ?? 0);
            if ($stock > 0) { $insSize->execute([$productId, $sz, $stock]); }
        }

        setFlash('success', $isEdit ? 'Product updated.' : 'Product added.');
        header('Location: products.php');
        exit;
    }

    foreach ($sizeOptions as $sz) { $stockBySize[$sz] = $postedSizes[$sz] ?? ''; }
}

include __DIR__ . '/includes/admin_header.php';
?>

<div class="admin-panel" style="max-width:760px;">
    <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= clean($e) ?></div><?php endforeach; ?>

    <form method="post" enctype="multipart/form-data">
        <?= csrfField() ?>
        <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= $productId ?>"><?php endif; ?>

        <div class="form-row">
            <div class="field">
                <label for="name">Product name</label>
                <input type="text" id="name" name="name" value="<?= clean($product['name']) ?>" required>
            </div>
            <div class="field">
                <label for="brand">Brand</label>
                <input type="text" id="brand" name="brand" value="<?= clean($product['brand']) ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="field">
                <label for="category_id">Category</label>
                <select id="category_id" name="category_id">
                    <option value="">— None —</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $product['category_id'] == $c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="price">Price (&#8369;)</label>
                <input type="number" id="price" name="price" step="0.01" min="0" value="<?= clean($product['price']) ?>" required>
            </div>
        </div>

        <div class="field">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4"><?= clean($product['description']) ?></textarea>
        </div>

        <div class="field">
            <label for="image">Product image</label>
            <img class="thumb-sm" style="width:64px;height:64px;margin-bottom:8px;" src="<?= productImageUrl($product['image'], true) ?>" alt="">
            <input type="file" id="image" name="image" accept=".jpg,.jpeg,.png,.webp">
            <div class="hint">JPG, PNG, or WEBP. Max 4MB. Leave blank to keep the current image.</div>
        </div>

        <div class="field">
            <label>Stock per size</label>
            <div class="form-row" style="grid-template-columns:repeat(4,1fr);gap:10px;">
                <?php foreach ($sizeOptions as $sz): ?>
                    <div>
                        <label style="font-weight:400;font-size:.78rem;color:var(--muted);">Size <?= $sz ?></label>
                        <input type="number" name="stock[<?= $sz ?>]" min="0" value="<?= clean((string)$stockBySize[$sz]) ?>" placeholder="0">
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="hint">Leave a size at 0 or blank if you don't carry it.</div>
        </div>

        <div class="field">
            <label><input type="checkbox" name="is_active" <?= $product['is_active'] ? 'checked' : '' ?> style="width:auto;"> Visible in shop</label>
        </div>

        <button type="submit" class="btn btn-accent"><?= $isEdit ? 'Save changes' : 'Add menu item' ?></button>
        <a href="products.php" class="btn btn-ghost">Cancel</a>
    </form>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
