<?php
require_once __DIR__ . '/includes/admin_auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: products.php'); exit; }
verifyCsrf();

$id = (int)($_POST['id'] ?? 0);
$pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);

setFlash('info', 'Product deleted.');
header('Location: products.php');
exit;
