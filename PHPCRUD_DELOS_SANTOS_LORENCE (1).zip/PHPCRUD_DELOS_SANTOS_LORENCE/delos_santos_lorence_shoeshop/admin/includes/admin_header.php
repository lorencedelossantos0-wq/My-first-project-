<?php
$flash = getFlash();
$current = basename($_SERVER['PHP_SELF']);
function navActive($file, $current) { return $file === $current ? 'active' : ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? clean($pageTitle) . ' — STRIDE Admin' : 'STRIDE Admin' ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="admin-shell">
    <aside class="admin-sidebar">
        <div class="brand">STRIDE<span>.</span></div>
        <div class="eyebrow" style="color:#8b9096;margin-bottom:18px;">Admin panel</div>
        <ul class="admin-nav">
            <li><a href="dashboard.php" class="<?= navActive('dashboard.php', $current) ?>">&#128202; Dashboard</a></li>
            <li><a href="products.php" class="<?= navActive('products.php', $current) ?>">&#128092; Menu items</a></li>
            <li><a href="categories.php" class="<?= navActive('categories.php', $current) ?>">&#128193; Categories</a></li>
            <li><a href="orders.php" class="<?= navActive('orders.php', $current) ?>">&#128230; Orders</a></li>
            <li><a href="reviews.php" class="<?= navActive('reviews.php', $current) ?>">&#9733; Reviews</a></li>
            <li><a href="customers.php" class="<?= navActive('customers.php', $current) ?>">&#128101; Customers</a></li>
            <div class="divider"></div>
            <li><a href="../index.php">&#8592; View shop site</a></li>
            <li><a href="../logout.php">&#128274; Logout</a></li>
        </ul>
    </aside>

    <main class="admin-main">
        <div class="admin-topbar">
            <h1><?= isset($pageTitle) ? clean($pageTitle) : 'Dashboard' ?></h1>
            <div class="who">Logged in as <?= clean($_SESSION['full_name']) ?></div>
        </div>
        <?php if ($flash): ?>
            <div class="alert alert-<?= clean($flash['type']) ?>"><?= clean($flash['message']) ?></div>
        <?php endif; ?>
