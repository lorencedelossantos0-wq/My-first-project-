<?php
require_once __DIR__ . '/includes/admin_auth.php';
$pageTitle = 'Customers';

$customers = $pdo->query("
    SELECT u.*, COUNT(o.id) AS order_count, COALESCE(SUM(CASE WHEN o.status != 'Cancelled' THEN o.total_amount ELSE 0 END),0) AS total_spent
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    WHERE u.role = 'customer'
    GROUP BY u.id
    ORDER BY u.created_at DESC
")->fetchAll();

include __DIR__ . '/includes/admin_header.php';
?>

<div class="table-wrap">
    <table>
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Total Spent</th><th>Joined</th></tr></thead>
        <tbody>
        <?php foreach ($customers as $c): ?>
            <tr>
                <td><?= clean($c['full_name']) ?></td>
                <td><?= clean($c['email']) ?></td>
                <td><?= clean($c['phone'] ?: '—') ?></td>
                <td><?= $c['order_count'] ?></td>
                <td><?= peso($c['total_spent']) ?></td>
                <td class="review-count"><?= date('M j, Y', strtotime($c['created_at'])) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($customers)): ?>
            <tr><td colspan="6" style="text-align:center;color:var(--muted);">No customers yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
