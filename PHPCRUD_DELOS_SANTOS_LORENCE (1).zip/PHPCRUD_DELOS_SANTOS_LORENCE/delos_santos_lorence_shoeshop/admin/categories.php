<?php
require_once __DIR__ . '/includes/admin_auth.php';
$pageTitle = 'Categories';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    verifyCsrf();
    $name = trim($_POST['name'] ?? '');
    if ($name !== '') {
        $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute([$name]);
        setFlash('success', 'Category added.');
    }
    header('Location: categories.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    verifyCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
    setFlash('info', 'Category deleted. Products in it were moved to "Uncategorized".');
    header('Location: categories.php');
    exit;
}

$categories = $pdo->query("
    SELECT c.*, COUNT(p.id) AS product_count
    FROM categories c LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id ORDER BY c.name
")->fetchAll();

include __DIR__ . '/includes/admin_header.php';
?>

<div class="admin-panel" style="max-width:420px;">
    <h3 style="margin-top:0;">Add category</h3>
    <form method="post" style="display:flex;gap:10px;">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add">
        <input type="text" name="name" placeholder="e.g. Skate" required>
        <button type="submit" class="btn btn-accent btn-sm">Add</button>
    </form>
</div>

<div class="table-wrap">
    <table>
        <thead><tr><th>Name</th><th>Products</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($categories as $c): ?>
            <tr>
                <td><?= clean($c['name']) ?></td>
                <td><?= $c['product_count'] ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                        <button type="submit" class="btn btn-ghost btn-sm" data-confirm="Delete this category?">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($categories)): ?>
            <tr><td colspan="3" style="text-align:center;color:var(--muted);">No categories yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
