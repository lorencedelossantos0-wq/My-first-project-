<?php
require_once __DIR__ . '/includes/admin_auth.php';
$pageTitle = 'Reviews';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id = (int)($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM reviews WHERE id = ?")->execute([$id]);
    setFlash('info', 'Review removed.');
    header('Location: reviews.php');
    exit;
}

$reviews = $pdo->query("
    SELECT r.*, u.full_name, p.name AS product_name, p.id AS product_id
    FROM reviews r
    JOIN users u ON u.id = r.user_id
    JOIN products p ON p.id = r.product_id
    ORDER BY r.created_at DESC
")->fetchAll();

include __DIR__ . '/includes/admin_header.php';
?>

<div class="table-wrap">
    <table>
        <thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Date</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($reviews as $r): ?>
            <tr>
                <td><a href="../product_detail.php?id=<?= $r['product_id'] ?>" target="_blank"><?= clean($r['product_name']) ?></a></td>
                <td><?= clean($r['full_name']) ?></td>
                <td><?= starRating($r['rating']) ?></td>
                <td style="max-width:280px;"><?= clean($r['comment']) ?></td>
                <td class="review-count"><?= timeAgo($r['created_at']) ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <?= csrfField() ?>
                        <input type="hidden" name="id" value="<?= $r['id'] ?>">
                        <button type="submit" class="btn btn-ghost btn-sm" data-confirm="Remove this review?">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($reviews)): ?>
            <tr><td colspan="6" style="text-align:center;color:var(--muted);">No reviews yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
