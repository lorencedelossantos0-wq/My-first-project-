<?php
require_once __DIR__ . '/includes/admin_auth.php';
$pageTitle = 'Menu Items';

$search = trim($_GET['search'] ?? '');
$where = '1=1';
$params = [];
if ($search !== '') {
    $where = '(p.name LIKE ? OR p.brand LIKE ?)';
    $params = ["%$search%", "%$search%"];
}

$sql = "
    SELECT p.*, c.name AS category_name, COALESCE(SUM(ps.stock),0) AS total_stock
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN product_sizes ps ON ps.product_id = p.id
    WHERE $where
    GROUP BY p.id
    ORDER BY p.created_at DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

include __DIR__ . '/includes/admin_header.php';
?>

<div class="toolbar">
    <form method="get">
        <input type="search" name="search" placeholder="Search menu items&hellip;" value="<?= clean($search) ?>">
        <button class="btn btn-outline btn-sm" type="submit">Search</button>
    </form>
    <a href="product_form.php" class="btn btn-accent">+ Add menu item</a>
</div>

<div class="table-wrap">
    <table>
        <thead>
            <tr><th></th><th>Menu item</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($products as $p): ?>
            <tr>
                <td><img class="thumb-sm" src="<?= productImageUrl($p['image'], true) ?>" alt=""></td>
                <td><strong><?= clean($p['name']) ?></strong><br><span class="review-count"><?= clean($p['brand']) ?></span></td>
                <td><?= clean($p['category_name'] ?? '—') ?></td>
                <td><?= peso($p['price']) ?></td>
                <td>
                    <?php if ($p['total_stock'] <= 0): ?>
                        <span class="badge badge-outstock">Out</span>
                    <?php elseif ($p['total_stock'] <= 5): ?>
                        <span class="badge badge-lowstock"><?= $p['total_stock'] ?> left</span>
                    <?php else: ?>
                        <span class="badge badge-instock"><?= $p['total_stock'] ?> in stock</span>
                    <?php endif; ?>
                </td>
                <td><?= $p['is_active'] ? '<span class="badge badge-instock">Active</span>' : '<span class="badge badge-outstock">Hidden</span>' ?></td>
                <td style="white-space:nowrap;">
                    <a href="product_form.php?id=<?= $p['id'] ?>" class="btn btn-ghost btn-sm">Edit</a>
                    <form action="product_delete.php" method="post" style="display:inline;">
                        <?= csrfField() ?>
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <button type="submit" class="btn btn-ghost btn-sm" data-confirm="Delete '<?= clean(addslashes($p['name'])) ?>'? This cannot be undone.">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
            <tr><td colspan="7" style="text-align:center;color:var(--muted);">No menu items found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
