<?php
require_once __DIR__ . '/includes/admin_auth.php';
$pageTitle = 'Dashboard';

$totalSales = (float)$pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status != 'Cancelled'")->fetchColumn();
$totalOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$pendingOrders = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")->fetchColumn();
$totalProducts = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE is_active = 1")->fetchColumn();
$lowStock = (int)$pdo->query("
    SELECT COUNT(*) FROM (
        SELECT product_id, SUM(stock) AS total_stock
        FROM product_sizes GROUP BY product_id HAVING total_stock <= 5
    ) t
")->fetchColumn();

// Sales for the last 7 days
$salesByDay = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $salesByDay[$date] = 0;
}
$rows = $pdo->query("
    SELECT DATE(order_date) AS d, SUM(total_amount) AS total
    FROM orders
    WHERE status != 'Cancelled' AND order_date >= (CURDATE() - INTERVAL 6 DAY)
    GROUP BY DATE(order_date)
")->fetchAll();
foreach ($rows as $r) { $salesByDay[$r['d']] = (float)$r['total']; }

// Order status breakdown
$statusRows = $pdo->query("SELECT status, COUNT(*) AS c FROM orders GROUP BY status")->fetchAll();
$statusLabels = []; $statusCounts = [];
foreach ($statusRows as $r) { $statusLabels[] = $r['status']; $statusCounts[] = (int)$r['c']; }

// Recent orders
$recentOrders = $pdo->query("
    SELECT o.*, u.full_name FROM orders o
    JOIN users u ON u.id = o.user_id
    ORDER BY o.order_date DESC LIMIT 8
")->fetchAll();

$categories = $pdo->query(
    "SELECT c.*, COUNT(p.id) AS product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id ORDER BY c.name"
)->fetchAll();

$customers = $pdo->query(
    "SELECT u.*, COUNT(o.id) AS order_count, COALESCE(SUM(CASE WHEN o.status != 'Cancelled' THEN o.total_amount ELSE 0 END),0) AS total_spent
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    WHERE u.role = 'customer'
    GROUP BY u.id
    ORDER BY u.created_at DESC"
)->fetchAll();

$products = $pdo->query(
    "SELECT p.*, c.name AS category_name, COALESCE(SUM(ps.stock),0) AS total_stock
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN product_sizes ps ON ps.product_id = p.id
    GROUP BY p.id
    ORDER BY p.created_at DESC"
)->fetchAll();

$reviews = $pdo->query(
    "SELECT r.*, u.full_name, p.name AS product_name, p.id AS product_id
    FROM reviews r
    JOIN users u ON u.id = r.user_id
    JOIN products p ON p.id = r.product_id
    ORDER BY r.created_at DESC"
)->fetchAll();

include __DIR__ . '/includes/admin_header.php';
?>

<div class="stat-grid">
    <div class="stat-card">
        <div class="label">Total Sales</div>
        <div class="value"><?= peso($totalSales) ?></div>
    </div>
    <div class="stat-card navy">
        <div class="label">Total Orders</div>
        <div class="value"><?= $totalOrders ?></div>
    </div>
    <div class="stat-card warn">
        <div class="label">Pending Orders</div>
        <div class="value"><?= $pendingOrders ?></div>
    </div>
    <div class="stat-card ok">
        <div class="label">Active Products</div>
        <div class="value"><?= $totalProducts ?></div>
    </div>
</div>

<?php if ($lowStock > 0): ?>
    <div class="alert alert-error"><?= $lowStock ?> product(s) are low on stock (5 pairs or fewer). <a href="products.php">Review inventory &rarr;</a></div>
<?php endif; ?>

<div class="chart-grid">
    <div class="chart-card">
        <h3>Sales &mdash; last 7 days</h3>
        <canvas id="salesChart" height="110"></canvas>
    </div>
    <div class="chart-card">
        <h3>Orders by status</h3>
        <canvas id="statusChart" height="110"></canvas>
    </div>
</div>

<div class="admin-panel">
    <div class="grid-2" style="gap:18px;">
        <section class="panel-card">
            <div class="flex-between" style="margin-bottom:16px;">
                <h3 style="margin:0;">Recent orders</h3>
                <a href="orders.php" class="btn btn-ghost btn-sm">View all &rarr;</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Order #</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($recentOrders as $o): ?>
                        <tr>
                            <td>#<?= $o['id'] ?></td>
                            <td><?= clean($o['full_name']) ?></td>
                            <td><?= date('M j, Y', strtotime($o['order_date'])) ?></td>
                            <td><?= peso($o['total_amount']) ?></td>
                            <td><span class="badge badge-<?= strtolower($o['status']) ?>"><?= clean($o['status']) ?></span></td>
                            <td><a href="order_view.php?id=<?= $o['id'] ?>" class="btn btn-ghost btn-sm">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($recentOrders)): ?>
                        <tr><td colspan="6" style="text-align:center;color:var(--muted);">No orders yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="panel-card">
            <div class="flex-between" style="margin-bottom:16px;">
                <h3 style="margin:0;">Products</h3>
                <a href="products.php" class="btn btn-ghost btn-sm">View all &rarr;</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ($products as $p): ?>
                        <tr>
                            <td><img class="thumb-sm" src="<?= productImageUrl($p['image'], true) ?>" alt=""></td>
                            <td><strong><?= clean($p['name']) ?></strong><br><span class="review-count"><?= clean($p['brand']) ?></span></td>
                            <td><?= clean($p['category_name'] ?? '—') ?></td>
                            <td><?= peso($p['price']) ?></td>
                            <td>
                                <?php if ($p['total_stock'] <= 0): ?>
                                    <span class="badge badge-outstock">Out</span>
                                <?php elseif ($p['total_stock'] <= 5): ?>
                                    <span class="badge badge-lowstock"><?= $p['total_stock'] ?> left</span>
                                <?php else: ?>
                                    <span class="badge badge-instock"><?= $p['total_stock'] ?> in stock</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $p['is_active'] ? '<span class="badge badge-instock">Active</span>' : '<span class="badge badge-outstock">Hidden</span>' ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($products)): ?>
                        <tr><td colspan="6" style="text-align:center;color:var(--muted);">No products found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <div class="grid-2" style="gap:18px; margin-top:24px;">
        <section class="panel-card">
            <div class="flex-between" style="margin-bottom:16px;">
                <h3 style="margin:0;">Categories</h3>
                <a href="categories.php" class="btn btn-ghost btn-sm">View all &rarr;</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Name</th><th>Products</th></tr></thead>
                    <tbody>
                    <?php foreach ($categories as $c): ?>
                        <tr>
                            <td><?= clean($c['name']) ?></td>
                            <td><?= $c['product_count'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($categories)): ?>
                        <tr><td colspan="2" style="text-align:center;color:var(--muted);">No categories yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="panel-card">
            <div class="flex-between" style="margin-bottom:16px;">
                <h3 style="margin:0;">Customers</h3>
                <a href="customers.php" class="btn btn-ghost btn-sm">View all &rarr;</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Name</th><th>Email</th><th>Orders</th></tr></thead>
                    <tbody>
                    <?php foreach ($customers as $c): ?>
                        <tr>
                            <td><?= clean($c['full_name']) ?></td>
                            <td><?= clean($c['email']) ?></td>
                            <td><?= $c['order_count'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($customers)): ?>
                        <tr><td colspan="3" style="text-align:center;color:var(--muted);">No customers yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <section class="panel-card" style="margin-top:24px;">
        <div class="flex-between" style="margin-bottom:16px;">
            <h3 style="margin:0;">Recent reviews</h3>
            <a href="reviews.php" class="btn btn-ghost btn-sm">View all &rarr;</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Date</th></tr></thead>
                <tbody>
                <?php foreach ($reviews as $r): ?>
                    <tr>
                        <td><?= clean($r['product_name']) ?></td>
                        <td><?= clean($r['full_name']) ?></td>
                        <td><?= starRating($r['rating']) ?></td>
                        <td style="max-width:240px; white-space:normal;"><?= clean($r['comment']) ?></td>
                        <td class="review-count"><?= timeAgo($r['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($reviews)): ?>
                    <tr><td colspan="5" style="text-align:center;color:var(--muted);">No reviews yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
const salesLabels = <?= json_encode(array_map(fn($d) => date('M j', strtotime($d)), array_keys($salesByDay))) ?>;
const salesData = <?= json_encode(array_values($salesByDay)) ?>;

new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
        labels: salesLabels,
        datasets: [{
            label: 'Sales (PHP)',
            data: salesData,
            borderColor: '#FF5A36',
            backgroundColor: 'rgba(255,90,54,.12)',
            fill: true,
            tension: .3,
            pointRadius: 3
        }]
    },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
});

const statusLabels = <?= json_encode($statusLabels) ?>;
const statusCounts = <?= json_encode($statusCounts) ?>;
new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: statusLabels,
        datasets: [{
            data: statusCounts,
            backgroundColor: ['#B9891C', '#1B3A63', '#3a5a8a', '#2E7D4F', '#C1352B']
        }]
    },
    options: { plugins: { legend: { position: 'bottom' } } }
});
</script>

<?php include __DIR__ . '/includes/admin_footer.php'; ?>
