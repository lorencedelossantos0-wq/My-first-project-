<?php
require __DIR__ . '/delos_santos_lorence_product_detail.php';
