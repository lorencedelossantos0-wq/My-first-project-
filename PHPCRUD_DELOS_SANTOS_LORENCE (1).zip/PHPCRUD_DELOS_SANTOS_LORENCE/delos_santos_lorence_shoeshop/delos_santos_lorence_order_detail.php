<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

$orderId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, currentUserId()]);
$order = $stmt->fetch();

if (!$order) { header('Location: orders.php'); exit; }

$pageTitle = 'Order #' . $order['id'];

$itemsStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();

$steps = ['Pending', 'Processing', 'Shipped', 'Delivered'];
$currentStepIndex = array_search($order['status'], $steps);

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / <a href="orders.php">My Orders</a> / Order #<?= $order['id'] ?></div>

<section class="section">
    <div class="section-head">
        <h2>Order #<?= $order['id'] ?></h2>
        <span class="badge badge-<?= strtolower($order['status']) ?>" style="font-size:.85rem;"><?= clean($order['status']) ?></span>
    </div>

    <?php if ($order['status'] === 'Cancelled'): ?>
        <div class="alert alert-error">This order was cancelled.</div>
    <?php else: ?>
    <ul class="tracker">
        <?php foreach ($steps as $i => $step): ?>
            <li class="<?= $i <= $currentStepIndex ? 'done' : '' ?>"><?= $step ?></li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:2fr 1fr;gap:32px;align-items:start;margin-top:20px;">
        <div class="table-wrap">
            <table>
                <thead><tr><th>Item</th><th>Size</th><th>Qty</th><th>Price</th></tr></thead>
                <tbody>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td><?= clean($it['product_name']) ?></td>
                        <td><?= clean($it['size']) ?></td>
                        <td><?= $it['quantity'] ?></td>
                        <td><?= peso($it['price'] * $it['quantity']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="cart-summary" style="position:static;">
            <h3 style="margin-top:0;">Delivery details</h3>
            <p style="margin-bottom:6px;"><strong><?= clean($order['shipping_name']) ?></strong></p>
            <p style="margin-bottom:6px;color:var(--ink-soft);"><?= nl2br(clean($order['shipping_address'])) ?></p>
            <p style="margin-bottom:14px;color:var(--ink-soft);"><?= clean($order['shipping_phone']) ?></p>
            <div class="summary-row"><span>Payment method</span><span><?= clean($order['payment_method']) ?></span></div>
            <div class="summary-row total"><span>Total</span><span><?= peso($order['total_amount']) ?></span></div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
