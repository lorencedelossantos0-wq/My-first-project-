<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: cart.php'); exit; }
verifyCsrf();

$cartId = (int)($_POST['cart_id'] ?? 0);
$action = $_POST['action'] ?? 'update';

// Make sure this cart row actually belongs to the logged-in user.
$stmt = $pdo->prepare("SELECT * FROM cart WHERE id = ? AND user_id = ?");
$stmt->execute([$cartId, currentUserId()]);
$item = $stmt->fetch();

if ($item) {
    if ($action === 'remove') {
        $pdo->prepare("DELETE FROM cart WHERE id = ?")->execute([$cartId]);
        setFlash('info', 'Item removed from cart.');
    } else {
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        $stockStmt = $pdo->prepare("SELECT stock FROM product_sizes WHERE product_id = ? AND size = ?");
        $stockStmt->execute([$item['product_id'], $item['size']]);
        $stock = (int)$stockStmt->fetchColumn();
        $qty = min($qty, max($stock, 1));
        $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?")->execute([$qty, $cartId]);
    }
}

header('Location: cart.php');
exit;
