<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

$pageTitle = 'Your Cart';

$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price, p.image,
           (SELECT stock FROM product_sizes ps WHERE ps.product_id = p.id AND ps.size = c.size) AS available_stock
    FROM cart c
    JOIN products p ON p.id = c.product_id
    WHERE c.user_id = ?
    ORDER BY c.created_at DESC
");
$stmt->execute([currentUserId()]);
$items = $stmt->fetchAll();

$subtotal = 0;
foreach ($items as $it) { $subtotal += $it['price'] * $it['quantity']; }
$shipping = $subtotal > 0 ? 120 : 0;
$total = $subtotal + $shipping;

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / Cart</div>

<section class="section">
    <h2>Your cart</h2>

    <?php if (empty($items)): ?>
        <div class="empty-state">
            <div class="icon">&#128092;</div>
            <p>Your cart is empty.</p>
            <a href="products.php" class="btn btn-primary">Browse shoes</a>
        </div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:32px;align-items:start;">
        <div>
            <?php foreach ($items as $it): ?>
                <?php $overStock = $it['quantity'] > $it['available_stock']; ?>
                <div class="cart-line">
                    <img src="<?= productImageUrl($it['image']) ?>" alt="<?= clean($it['name']) ?>">
                    <div>
                        <strong><?= clean($it['name']) ?></strong><br>
                        <span class="review-count">Size <?= clean($it['size']) ?> &middot; <?= peso($it['price']) ?> each</span>
                        <?php if ($overStock): ?>
                            <div class="badge badge-lowstock" style="margin-top:4px;">Only <?= $it['available_stock'] ?> left in stock</div>
                        <?php endif; ?>
                    </div>
                    <form method="post" action="cart_update.php" class="qty-stepper" style="display:flex;align-items:center;gap:6px;">
                        <?= csrfField() ?>
                        <input type="hidden" name="cart_id" value="<?= $it['id'] ?>">
                        <button type="button" class="btn btn-ghost btn-sm" data-step="-1">&minus;</button>
                        <input type="number" class="qty-input" name="quantity" value="<?= $it['quantity'] ?>" min="1" max="<?= max($it['available_stock'],1) ?>" readonly>
                        <button type="button" class="btn btn-ghost btn-sm" data-step="1">+</button>
                    </form>
                    <strong><?= peso($it['price'] * $it['quantity']) ?></strong>
                    <form method="post" action="cart_update.php">
                        <?= csrfField() ?>
                        <input type="hidden" name="cart_id" value="<?= $it['id'] ?>">
                        <input type="hidden" name="action" value="remove">
                        <button type="submit" class="btn btn-ghost btn-sm" data-confirm="Remove this item from your cart?">Remove</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="cart-summary">
            <h3 style="margin-top:0;">Order summary</h3>
            <div class="summary-row"><span>Subtotal</span><span><?= peso($subtotal) ?></span></div>
            <div class="summary-row"><span>Shipping</span><span><?= peso($shipping) ?></span></div>
            <div class="summary-row total"><span>Total</span><span><?= peso($total) ?></span></div>
            <a href="checkout.php" class="btn btn-accent btn-block" style="margin-top:14px;">Proceed to checkout</a>
        </div>
    </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
