<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
requireLogin();

$pageTitle = 'My Profile';
$errors = [];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([currentUserId()]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $fullName = trim($_POST['full_name'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';

    if ($fullName === '') $errors[] = 'Full name is required.';

    if (empty($errors)) {
        if ($newPassword !== '') {
            if (strlen($newPassword) < 6) {
                $errors[] = 'New password must be at least 6 characters.';
            } else {
                $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                $pdo->prepare("UPDATE users SET full_name=?, phone=?, address=?, password=? WHERE id=?")
                    ->execute([$fullName, $phone, $address, $hash, currentUserId()]);
            }
        } else {
            $pdo->prepare("UPDATE users SET full_name=?, phone=?, address=? WHERE id=?")
                ->execute([$fullName, $phone, $address, currentUserId()]);
        }

        if (empty($errors)) {
            $_SESSION['full_name'] = $fullName;
            setFlash('success', 'Profile updated.');
            header('Location: profile.php');
            exit;
        }
    }

    $user = array_merge($user, ['full_name' => $fullName, 'phone' => $phone, 'address' => $address]);
}

include 'includes/header.php';
?>

<div class="crumb"><a href="index.php">Home</a> / Profile</div>

<section class="section">
    <div class="form-card">
        <h2 class="text-center">My profile</h2>

        <?php foreach ($errors as $e): ?>
            <div class="alert alert-error"><?= clean($e) ?></div>
        <?php endforeach; ?>

        <form method="post">
            <?= csrfField() ?>
            <div class="field">
                <label>Email</label>
                <input type="email" value="<?= clean($user['email']) ?>" disabled>
            </div>
            <div class="field">
                <label for="full_name">Full name</label>
                <input type="text" id="full_name" name="full_name" value="<?= clean($user['full_name']) ?>" required>
            </div>
            <div class="field">
                <label for="phone">Phone</label>
                <input type="tel" id="phone" name="phone" value="<?= clean($user['phone']) ?>">
            </div>
            <div class="field">
                <label for="address">Default delivery address</label>
                <textarea id="address" name="address"><?= clean($user['address']) ?></textarea>
            </div>
            <div class="field">
                <label for="new_password">New password <span class="hint">(leave blank to keep current)</span></label>
                <input type="password" id="new_password" name="new_password">
            </div>
            <button type="submit" class="btn btn-accent btn-block">Save changes</button>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
