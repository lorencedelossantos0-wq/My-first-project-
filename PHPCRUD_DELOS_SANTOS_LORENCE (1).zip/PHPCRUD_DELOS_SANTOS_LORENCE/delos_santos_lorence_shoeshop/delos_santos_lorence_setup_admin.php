<?php
/**
 * Run this file ONCE in your browser after importing database.sql:
 *   http://localhost/shoeshop/setup_admin.php
 * It safely sets the demo admin password, then tells you to delete this file.
 */
require_once 'config/database.php';

$defaultEmail = 'admin@stride.com';
$defaultPassword = 'admin123';

$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$defaultEmail]);
$admin = $stmt->fetch();

if (!$admin) {
    die('No admin row found. Did you import database.sql?');
}

$hash = password_hash($defaultPassword, PASSWORD_DEFAULT);
$pdo->prepare("UPDATE users SET password = ? WHERE email = ?")->execute([$hash, $defaultEmail]);

echo "<div style='font-family:sans-serif;max-width:500px;margin:60px auto;padding:24px;border:1px solid #ddd;border-radius:6px;'>";
echo "<h2 style='margin-top:0;'>&#9989; Admin password set</h2>";
echo "<p>You can now log in with:</p>";
echo "<p><strong>Email:</strong> $defaultEmail<br><strong>Password:</strong> $defaultPassword</p>";
echo "<p style='color:#a12a22;'><strong>Important:</strong> delete this file (setup_admin.php) now for security &mdash; anyone who visits it can reset the admin password.</p>";
echo "<p><a href='login.php'>Go to login &rarr;</a></p>";
echo "</div>";
