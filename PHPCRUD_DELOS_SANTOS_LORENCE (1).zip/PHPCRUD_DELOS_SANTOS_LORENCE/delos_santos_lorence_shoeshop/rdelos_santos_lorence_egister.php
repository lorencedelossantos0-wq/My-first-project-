<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (isLoggedIn()) { header('Location: index.php'); exit; }

$pageTitle = 'Register';
$errors = [];
$old = ['full_name' => '', 'email' => '', 'phone' => '', 'address' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $old['full_name'] = trim($_POST['full_name'] ?? '');
    $old['email']     = trim($_POST['email'] ?? '');
    $old['phone']     = trim($_POST['phone'] ?? '');
    $old['address']   = trim($_POST['address'] ?? '');
    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password_confirm'] ?? '';

    if ($old['full_name'] === '') $errors[] = 'Full name is required.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $password2) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$old['email']]);
        if ($check->fetch()) {
            $errors[] = 'That email is already registered. Try logging in instead.';
        }
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, phone, address, role) VALUES (?, ?, ?, ?, ?, 'customer')");
        $stmt->execute([$old['full_name'], $old['email'], $hash, $old['phone'], $old['address']]);

        $_SESSION['user_id']   = $pdo->lastInsertId();
        $_SESSION['full_name'] = $old['full_name'];
        $_SESSION['role']      = 'customer';

        setFlash('success', 'Welcome to STRIDE, ' . $old['full_name'] . '!');
        header('Location: index.php');
        exit;
    }
}

include 'includes/header.php';
?>

<section class="section" style="padding-top:10px;">
    <div class="form-card">
        <div class="eyebrow text-center" style="text-align:center;">Join STRIDE</div>
        <h2 class="text-center">Create your account</h2>

        <?php foreach ($errors as $e): ?>
            <div class="alert alert-error"><?= clean($e) ?></div>
        <?php endforeach; ?>

        <form method="post" novalidate>
            <?= csrfField() ?>
            <div class="field">
                <label for="full_name">Full name</label>
                <input type="text" id="full_name" name="full_name" value="<?= clean($old['full_name']) ?>" required>
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?= clean($old['email']) ?>" required>
            </div>
            <div class="form-row">
                <div class="field">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="field">
                    <label for="password_confirm">Confirm password</label>
                    <input type="password" id="password_confirm" name="password_confirm" required>
                </div>
            </div>
            <div class="field">
                <label for="phone">Phone (optional)</label>
                <input type="tel" id="phone" name="phone" value="<?= clean($old['phone']) ?>">
            </div>
            <div class="field">
                <label for="address">Address (optional, used at checkout)</label>
                <textarea id="address" name="address"><?= clean($old['address']) ?></textarea>
            </div>
            <button type="submit" class="btn btn-accent btn-block">Create account</button>
        </form>
        <p class="form-foot">Already have an account? <a href="login.php">Log in</a></p>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
