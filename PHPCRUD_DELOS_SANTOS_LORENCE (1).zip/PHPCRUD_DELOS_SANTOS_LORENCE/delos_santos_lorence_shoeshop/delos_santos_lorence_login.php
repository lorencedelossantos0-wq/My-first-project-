<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (isLoggedIn()) { header('Location: ' . (isAdmin() ? 'admin/dashboard.php' : 'index.php')); exit; }

$pageTitle = 'Login';
$errors = [];
$email = '';
$next = $_GET['next'] ?? $_POST['next'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        $errors[] = 'Incorrect email or password.';
    } else {
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role']      = $user['role'];

        if ($user['role'] === 'admin') {
            header('Location: admin/dashboard.php');
        } else {
            setFlash('success', 'Welcome back, ' . $user['full_name'] . '!');
            header('Location: ' . ($next ?: 'index.php'));
        }
        exit;
    }
}

include 'includes/header.php';
?>

<section class="section" style="padding-top:10px;">
    <div class="form-card">
        <div class="eyebrow text-center" style="text-align:center;">Welcome back</div>
        <h2 class="text-center">Log in</h2>

        <?php foreach ($errors as $e): ?>
            <div class="alert alert-error"><?= clean($e) ?></div>
        <?php endforeach; ?>

        <form method="post" novalidate>
            <?= csrfField() ?>
            <input type="hidden" name="next" value="<?= clean($next) ?>">
            <div class="field">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?= clean($email) ?>" required autofocus>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-accent btn-block">Log in</button>
        </form>
        <p class="form-foot">New to STRIDE? <a href="register.php">Create an account</a></p>
        <p class="form-foot" style="font-family:var(--font-mono);font-size:.72rem;">Admin demo: admin@stride.com</p>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
