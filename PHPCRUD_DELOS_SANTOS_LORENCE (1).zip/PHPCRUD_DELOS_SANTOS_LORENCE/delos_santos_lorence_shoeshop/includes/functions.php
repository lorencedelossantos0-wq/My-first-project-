<?php
/**
 * Shared helper functions used across the whole site.
 * Included after session_start() + database.php in every page.
 */

// ---------- Sanitization ----------
function clean($value) {
    return htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// ---------- Auth helpers ----------
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && ($_SESSION['role'] ?? '') === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php?next=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header('Location: ../login.php');
        exit;
    }
}

function currentUserId() {
    return $_SESSION['user_id'] ?? null;
}

// ---------- CSRF protection ----------
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . csrfToken() . '">';
}

function verifyCsrf() {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        die('Security check failed. Please go back and try again.');
    }
}

// ---------- Formatting ----------
function peso($amount) {
    return '&#8369;' . number_format((float)$amount, 2);
}

function starRating($rating, $outOf = 5) {
    $rating = round($rating);
    $html = '<span class="stars" aria-label="' . $rating . ' out of ' . $outOf . ' stars">';
    for ($i = 1; $i <= $outOf; $i++) {
        $html .= $i <= $rating ? '&#9733;' : '&#9734;';
    }
    return $html . '</span>';
}

function timeAgo($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    if ($diff < 2592000) return floor($diff / 86400) . 'd ago';
    return date('M j, Y', strtotime($datetime));
}

// ---------- Cart ----------
function cartCount($pdo) {
    if (!isLoggedIn()) return 0;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) FROM cart WHERE user_id = ?");
    $stmt->execute([currentUserId()]);
    return (int)$stmt->fetchColumn();
}

// ---------- Flash messages (session-based, one-time) ----------
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (empty($_SESSION['flash'])) return null;
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

// ---------- Image upload (used by admin product form) ----------
function handleProductImageUpload($fileInputName, $uploadDir, $currentImage = 'no-image.svg') {
    if (empty($_FILES[$fileInputName]['name'])) {
        return [true, $currentImage]; // no new file chosen, keep existing
    }
    $file = $_FILES[$fileInputName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [false, 'Upload error. Please try again.'];
    }
    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!array_key_exists($ext, $allowed)) {
        return [false, 'Only JPG, PNG, or WEBP images are allowed.'];
    }
    if ($file['size'] > 4 * 1024 * 1024) {
        return [false, 'Image must be smaller than 4MB.'];
    }
    $newName = 'product_' . uniqid() . '.' . $ext;
    $destination = rtrim($uploadDir, '/') . '/' . $newName;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return [false, 'Could not save the uploaded file.'];
    }
    return [true, $newName];
}

function productImageUrl($image, $fromAdmin = false) {
    $prefix = $fromAdmin ? '../' : '';
    if ($image === 'no-image.svg' || empty($image)) {
        return $prefix . 'assets/images/no-image.svg';
    }
    return $prefix . 'uploads/products/' . $image;
}
