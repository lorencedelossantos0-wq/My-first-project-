</main>

<footer class="site-footer">
    <div class="container">
        <div>
            <div class="brand">STRIDE<span>.</span></div>
            <p style="margin:0;color:#8b9096;">Sneakers, sorted. &mdash; a shoe shop system built with PHP &amp; MySQL.</p>
        </div>
        <div style="font-family:var(--font-mono);font-size:.8rem;">
            &copy; <?= date('Y') ?> STRIDE. All rights reserved.
        </div>
    </div>
</footer>

<script src="assets/js/script.js"></script>
</body>
</html>
