<?php
/**
 * Expects $pdo, session already started, and functions.php already included.
 * Optional: $pageTitle
 */
$flash = getFlash();
$currentCartCount = cartCount($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? clean($pageTitle) . ' — STRIDE' : 'STRIDE — Sneakers, sorted.' ?></title>
<link rel="icon" href="data:,">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="index.php" class="brand">STRIDE<span>.</span></a>
        <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">&#9776;</button>
        <ul class="nav-links" id="navLinks">
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Shop</a></li>
            <?php if (isLoggedIn()): ?>
                <li><a href="orders.php">My Orders</a></li>
                <li><a href="profile.php">Profile</a></li>
                <?php if (isAdmin()): ?><li><a href="admin/dashboard.php">Admin</a></li><?php endif; ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            <?php endif; ?>
            <li>
                <a href="cart.php" class="nav-cart" aria-label="Cart">
                    &#128092; Cart
                    <?php if ($currentCartCount > 0): ?>
                        <span class="cart-badge"><?= $currentCartCount ?></span>
                    <?php endif; ?>
                </a>
            </li>
        </ul>
    </div>
</nav>

<main>
<div class="container" style="padding-top:18px;">
<?php if ($flash): ?>
    <div class="alert alert-<?= clean($flash['type']) ?>"><?= clean($flash['message']) ?></div>
<?php endif; ?>
</div>
